Interface IAnimationModel represents the core animation. The interface supports adding and removing
shapes as well as adding and removing motions from those shapes. The animateString() method returns
a string representation of the animation. The animateGraphic() method returns a visual display
of one tick of the animation. This method was not tested since its implementation may vary
depending on the controller/view and the display is better left for testing within the view.

Class AnimationModelImpl implements IAnimationModel and stores a map of shape names to
IAnimationShapes.

Interface IAnimationShape represents a single animated shape. it supports adding and removing
motions as well as animateString() and animateGraphic() as detailed above. It also has a type()
method which returns a string representing the object's type. Shapes exist only as a list of
motions, meaning that any tick outside its IMotions represents the shape having disappeared.

Abstract class AnimationShape implements IAnimationShape and stores a list of IMotions. It also
ensures that the IMotions can not intersect. This class implements all of the interface methods
except for animateGraphic() and type() since those are shape-dependent. It also implements three
protected getter methods for subclasses to use in their animateGraphic() method.

Classes AnimatedOval, AnimatedRect, and AnimatedTriangle all extend AnimationShape and implement
IAnimationShape. They define the type() and animateGraphic() methods according to their specific
shape. No other methods are overridden. Further classes can be added easily for other shapes.

Interface IMotion represents a motion of a shape from a start to end position over a given tick
interval. It supports the animateString() method as detailed above. It supports getters for the
start and end tick. It also supports getters for position, size, and color at a given tick.

Class Motion implements IMotion and stores a EnumMap of Property to int value. The enum is
defined in the IMotion interface. A Motion must have a map of exactly 16 positive values. The
position properties in the motion represents the top left corner of the bounding rectangle of a
shape. The size properties represent the width and height of the bounding rectangle. The equals and
hashCode() methods are overridden to allow removing motions.

Assumptions:
1. The Model is in charge of producing the image, it takes in an Image Object and draws all
shapes onto it at any given tick. The Controller will pass the Model a tick when an Image needs
to be updated.
2. A Shape has no fields except its list of motions because the shape only appears when Motions are
defined. Its position, size, and color are always determined from its motions.
3. Motions on the same shape cannot intersect.
4. Motions on the same shape can have gaps, but the shape is assumed to disappear during that gap.
5. Adding a shape with the same name as a current shape will override the previous shape.
6. Filled vs. outlined shapes can both be drawn, but have separate classes.
7. The maximum tick is determined by the controller. The model is capable of drawing at any tick,
even after all shapes have disappeared.
----------------------------------------------------------------------------------------------------
Changelog (Assignment 6):
- IReadOnlyModel was added so views can not directly modify models. IAnimationModel now extends from
IReadOnlyModel. Two new methods in IReadOnlyModel are getShapes() and getBounds() which return the
related fields.
- IAnimationModel no longer contains addMotion() and addShape() since these were in the provided
builder. The constructor was also changed to be private.
- IReadOnlyShape was added so views can not directly modify shapes. IAnimationShape
now extends IReadOnlyShape. IReadOnlyShape contains type(), animateString(), and animateGraphic()
moved from IAnimationShape. It also contains the new animateSVG() method.
- IMotion was already immutable so no read only was made. However, the new method animateSVG()
was added.
- The IMotion transition method was built to assume intervals of size 0 are denied by the
constructor. Our implementation would have instead defined object appearance as its first motion,
not a separate call. This raises issues in the provided toh.txt since objects were given appear
motions that have intervals of 0. We had to change the constructor and the private transition
methods to accommodate this.

Additions (Assignment 6):
-The IView interface was added which contains only the render method. It renders a given model
with results depending on class implementations.
-TextualView implements IView and takes in an Appendable in its constructor which represents
the output location. Its render method returns a string representation of the animation.
-SVGView implements IView and takes in an Appendable and a tick rate. Its render method returns
an SVG representation of the animation.
-GraphicView extends JFrame and implements IView and takes in a tick rate. Its render method
displays the animation as a panel on a JFrame. It also has a nested Animation class which extends
JPanel and overwrites the paintComponent() method.
-The IViewFactory interface defines a static method called createView that takes in the type of
view and additional parameters. If view type is valid, it returns an IView.
-Excellence contains the main method and parses command line arguments. It must take an input file
and a view type, but output files and speeds are optional. They default to System.out and 1.
To access the input file by relative path, it must be placed in the Resources.Provided directory.
Adding an output file by relative path will place it in the Resources directory.
----------------------------------------------------------------------------------------------------
Changelog/Additions (Assignment 7)
- There is a brand new interface IKeyframe and associated Keyframe class. These were created to
simplify the addition and removal of keyframes from shapes. They represent exactly one half
of a motion. Keyframe has a getState method which returns a map of Properties to their integer
value, as well as a convenience method getStart that returns only the tick property.
- The Motion constructor was changed to take in two keyframes instead of all of the params so that
it works better with the new keyframe class. Its methods were changed to work with two keyframes,
but maintain the same behavior as before. The only exception is that the getColor, getSize, and
getPosition methods were merged into a single getState method for convenience and performance.
- In IAnimationShape and all implementing classes, AddMotion and removeMotion were changed to
addKeyframe and removeKeyframe to work better with keyframes. AddKeyframe is also capable of
editing/overriding existing keyframes at the same tick, to support editor functionality. The
AnimationShape class now has a private internal makeMotion method that converts keyframes to motions
when needed for other methods. Another new method, getFrames was added so frames can be retrieved
and displayed in the new view.
- IReadOnlyModel method getBounds was replaced with getAttributes to support the new addition
of starting and ending ticks. IAnimationModel now has addKeyframe, removeKeyframe, addShape, and
removeShape to support all editor view functionality. Since these cover all the methods used by the
builder, it was rewritten entirely to only use external class methods.
- IView received two new methods renderVisual and setListener which were needed for the editor
view. SVGView and TextualView raise UnsupportedOperationExceptions for both methods. GraphicView
now uses renderVisual and throws UnsupportedOperationExceptions for render and setListener. The
view was also changed to not have any internal fields or classes since this is now handled by
a controller. The internal DrawingPanel class was moved outside the GraphicView and now implements
a new IDrawingPanel interface as well as the associated draw() method.
- A new ListPanel class was created that implements IDrawingPanel and is used to display the list
of shapes and keyframes for the editor view.
- The editorView is a new view implementing IView and extending GraphicView. It overrides the render
visual method slightly to add ListPanel support. It also uses the setListener method to accept a
controller. The controller responds to actionCommands and applies the appropriate action.
- The new IController interface implements all of the behavior required for editor views as well
as a run method used to set up a timer. EditorController implements this interface and now controls
tick rate, current tick, and other playback fields. It is also capable of mutating models.
----------------------------------------------------------------------------------------------------
Changelog/Additions (Assignment 8)
Level 1:
- Added a scrollbar JComponent to our editor view
- Added a new method to IController to set tick to a given int
- Changed view render method to also update scroll bar bounds (in case they change at runtime)
Level 2:
- Added a rotation property to keyframes and ensured all keyframes have 9 properties
- Changed AnimationReader to read degrees. Not providing degrees still works, AnimationReader
 defaults them to 0. A single motion line must either have degrees for both frames or neither
- Changed AnimatedRect and AnimatedEllipse to include rotation when drawn
- Changed AnimationModel and associated builder to use 9 params for keyframes
- Changed EditorView to take in new param when making keyframes
Level 3:
- Added field layerOrder to AnimationModel that maintains an order of layers
- Added field layers to AnimationModel that maintains shapes stored in each layer
- Added methods getLayerOrder and getLayers to IReadOnlyModel
- Added methods addLayer, removeLayer, reorderLayers to IAnimationModel
- Added method moveShapes to AnimationModel (not required by assignment)
- Revised addShape method to take in a layer for the shape
- Modified AnimationReader to read layers and give them "default" layer if not present
- Modified DrawingPanel to display shapes in the new layer order
- Modified ListPanel to now also display layers and select them to see their shapes.
- Modified EditorView to have GUI tabs for addLayer, removeLayer, reorderLayer, and moveShape
- Revised EditorView to take in new param when adding shapes
- Added addLayer, removeLayer, reorderLayer, and moveShape to IController
