package cs3500.animator.controller;

/**
 * Interface for the methods on a controller.
 */
public interface IController {
  /**
   * Starts the animation in this controller.
   */
  void run();

  /**
   * Switches the animation from pause to resume.
   *
   */
  void togglePause();

  /**
   * Rewinds the animation to the start, not necessarily tick 0.
   */
  void rewind();

  /**
   * Sets the current tick to the given int
   */
  void setTick(int tick);

  /**
   * Switches the animation from looping to endless.
   *
   */
  void toggleLoop();

  /**
   * Sets the tickRate to the given rate.
   *
   * @param tickRate new tick rate.
   */
  void setTickRate(int tickRate);

  /**
   * Adds the given layer to the stored model.
   *
   * @param name is the layer name
   */
  void addLayer(String name);

  /**
   * Removes the given layer from the stored model.
   *
   * @param name is the layer name
   */
  void removeLayer(String name);

  /**
   * Reorders the two given layers.
   *
   * @param layer1 is the first layer
   * @param layer2 is the second layer
   */
  void reorderLayer(String layer1, String layer2);

  /**
   * Adds a shape to the stored model.
   *
   * @param layer is the layer to add the shape to
   * @param name is the name of the shape
   * @param type if the shape type
   * @throws IllegalArgumentException if name is null or taken
   * @throws IllegalArgumentException if type is undefined
   */
  void addShape(String layer, String name, String type);

  /**
   * Removes the given shape from the stored model.
   *
   * @param name is the name of the shape
   */
  void removeShape(String name);

  /**
   * Moves the given shape to the given layer
   *
   * @param name is the name of the shape
   * @param layer is the name of the layer
   */
  void moveShape(String name, String layer);

  /**
   * Adds a keyframe to the specified shape of the stored model.
   *
   * @param name is the name of the shape
   * @param params is the keyframe
   * @throws IllegalArgumentException if name is not present
   */
  void addEditKeyframe(String name, int... params);

  /**
   * Removes a keyframe from the specified shape.
   *
   * @param name is the name of the shape
   * @param tick is the keyframe to remove
   * @throws IllegalArgumentException if name is not present
   */
  void removeKeyframe(String name, int tick);
}
