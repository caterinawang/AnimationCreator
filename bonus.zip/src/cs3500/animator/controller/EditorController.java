package cs3500.animator.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Map;

import javax.swing.Timer;

import cs3500.animator.view.IView;
import cs3500.model.Attribute;
import cs3500.model.IAnimationModel;

/**
 * Controller for editor views that supports modifying both the view and model.
 */
public class EditorController implements IController {
  private final IView view;
  private final IAnimationModel model;
  private final Timer timer;
  private int currentTick;
  private boolean paused;
  private boolean loop;

  /**
   * Class to represent a listener for a JSwing Timer.
   */
  private class TimerListener implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {
      view.renderVisual(model, currentTick);
      if (!paused) {
        currentTick++;
      }
      Map<Attribute, Integer> attributes = model.getAttributes();
      if (loop && attributes.get(Attribute.end) < currentTick) {
        currentTick = attributes.get(Attribute.start);
      }
    }
  }

  /**
   * Constructs a controller for the given view and model.
   *
   * @param model is the mutable model
   * @throws IllegalArgumentException if model or view is null
   * @throws IllegalArgumentException if tick rate is negative
   */
  public EditorController(IAnimationModel model, IView view, int tickRate) {
    if (model == null || view == null) {
      throw new IllegalArgumentException("Invalid Model or View");
    }
    if (tickRate < 0) {
      throw new IllegalArgumentException("Invalid tick rate. Must be positive");
    }
    this.view = view;
    this.model = model;
    this.timer = new Timer(tickRate, new TimerListener());
    this.currentTick = model.getAttributes().get(Attribute.start);
    this.paused = false;
    this.loop = false;
  }

  @Override
  public void run() {
    timer.start();
  }

  @Override
  public void addShape(String layer, String name, String type) {
    this.model.addShape(layer, name, type);
  }

  @Override
  public void removeShape(String name) {
    this.model.removeShape(name);
  }

  @Override
  public void moveShape(String name, String layer) {
    this.model.moveShape(name, layer);
  }

  @Override
  public void addEditKeyframe(String name, int... params) {
    this.model.addKeyframe(name, params);
  }

  @Override
  public void removeKeyframe(String name, int tick) {
    this.model.removeKeyframe(name, tick);
  }

  @Override
  public void togglePause() {
    this.paused = !this.paused;
  }

  @Override
  public void rewind() {
    this.currentTick = model.getAttributes().get(Attribute.start);
  }

  @Override
  public void setTick(int tick) {
    this.currentTick = tick;
  }

  @Override
  public void toggleLoop() {
    this.loop = !this.loop;
  }

  @Override
  public void setTickRate(int tickRate) {
    this.timer.setDelay(tickRate);
  }

  @Override
  public void addLayer(String name) {
    this.model.addLayer(name);
  }

  @Override
  public void removeLayer(String name) {
    this.model.removeLayer(name);
  }

  @Override
  public void reorderLayer(String layer1, String layer2) {
    this.model.reorderLayer(layer1, layer2);
  }
}
