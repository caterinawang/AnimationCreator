package cs3500.animator.view;

import cs3500.animator.controller.IController;
import cs3500.model.IReadOnlyModel;

/**
 * An interface representing methods on a view.
 */
public interface IView {
  /**
   * Renders an animation depending on class implementation.
   *
   * @param model represents the animation.
   */
  void render(IReadOnlyModel model);

  /**
   * Renders the shapes of an animation at the given tick.
   */
  void renderVisual(IReadOnlyModel model, int tick);

  /**
   * Sets a listener for this view, so it can send commands.
   */
  void setListener(IController listener);
}
