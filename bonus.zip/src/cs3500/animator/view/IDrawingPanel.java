package cs3500.animator.view;

import cs3500.model.IReadOnlyModel;

/**
 * Interface for methods supported by animation panels.
 */ 
public interface IDrawingPanel {
  /**
   * Draws the given list of shapes on this panel.
   */
  void draw(IReadOnlyModel model, int tick);
}
