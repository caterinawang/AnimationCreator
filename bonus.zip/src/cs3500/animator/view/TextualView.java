package cs3500.animator.view;

import java.io.IOException;
import java.util.Map;

import cs3500.animator.controller.IController;
import cs3500.model.Attribute;
import cs3500.model.IReadOnlyModel;
import cs3500.model.IReadOnlyShape;

/**
 * a class used to render animations textually.
 */
public class TextualView implements IView {
  private final Appendable out;

  /**
   * the constructor used to create text output given an Appendable.
   *
   * @param out represents the Appendable given.
   */
  TextualView(Appendable out) {
    this.out = out;
  }

  @Override
  public void render(IReadOnlyModel model) {
    if (model == null) {
      throw new IllegalArgumentException("Must supply a model.");
    }
    Map<String, IReadOnlyShape> shapes = model.getShapes();
    StringBuilder s = new StringBuilder();
    Map<Attribute, Integer> attributes = model.getAttributes();
    String canvas = "canvas " + attributes.get(Attribute.left) + " " + attributes.get(Attribute.top)
            + " " + attributes.get(Attribute.right) + " " + attributes.get(Attribute.bottom) + "\n";
    s.append(canvas);
    for (String name : shapes.keySet()) {
      String header = "shape " + name + " " + shapes.get(name).type() + "\n";
      s.append(header);
      s.append(shapes.get(name).animateString());
      s.append("\n");
    }
    String toReturn = s.toString();
    if (toReturn.length() > 0) {
      toReturn = toReturn.substring(0, toReturn.length() - 1);
    }
    try {
      this.out.append(toReturn);
    } catch (IOException e) {
      throw new IllegalStateException("Cannot Append.");
    }
  }

  @Override
  public void renderVisual(IReadOnlyModel model, int tick) {
    throw new UnsupportedOperationException("Can not visually render models");
  }

  @Override
  public void setListener(IController listener) {
    throw new UnsupportedOperationException("Listener can not be added to this view");
  }
}
