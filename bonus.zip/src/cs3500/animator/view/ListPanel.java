package cs3500.animator.view;

import java.awt.Dimension;
import java.util.List;
import java.util.Map;

import javax.swing.JSplitPane;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.DefaultListModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import cs3500.model.IKeyframe;
import cs3500.model.IReadOnlyModel;
import cs3500.model.IReadOnlyShape;

/**
 * A class to represent a panel displaying lists of shapes and frames.
 */
public class ListPanel extends JSplitPane implements IDrawingPanel, ListSelectionListener {
  private final JList<String> listLayers = new JList<>();
  private final JList<String> listShapes = new JList<>();
  private final JList<String> listMotions = new JList<>();
  private int selectedLayer = 0;
  private int selectedShape = 0;

  /**
   * Constructor to set up this list pane with all necessary components.
   */
  public ListPanel() {
    super(JSplitPane.HORIZONTAL_SPLIT);
    JSplitPane secondSplit = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
            new JScrollPane(this.listShapes), new JScrollPane(this.listMotions));
    secondSplit.setOneTouchExpandable(true);
    secondSplit.setDividerLocation(100);

    this.setLeftComponent(new JScrollPane(this.listLayers));
    this.setRightComponent(secondSplit);
    this.setOneTouchExpandable(true);
    this.setDividerLocation(100);
    this.listLayers.addListSelectionListener(this);
    this.listLayers.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    this.listShapes.addListSelectionListener(this);
    this.listShapes.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    this.setPreferredSize(new Dimension(415, 0));
  }

  @Override
  public void draw(IReadOnlyModel model, int tick) {
    List<String> layers = model.getLayerOrder();
    DefaultListModel<String> layerModel = new DefaultListModel<>();
    for (String name : layers) {
      layerModel.addElement(name);
    }
    this.listLayers.setModel(layerModel);

    if (this.selectedLayer < layers.size()) {
      DefaultListModel<String> shapesModel = new DefaultListModel<>();
      for (String shapeName : model.getLayers().get(layerModel.get(selectedLayer))) {
        shapesModel.addElement(shapeName);
      }
      this.listShapes.setModel(shapesModel);

      if (this.selectedShape < shapesModel.size()) {
        DefaultListModel<String> framesModel = new DefaultListModel<>();
        for (IKeyframe keyframe :
                model.getShapes().get(shapesModel.get(selectedShape)).getFrames()) {
          StringBuilder s = new StringBuilder();
          for (int val : keyframe.getState().values()) {
            s.append(val);
            s.append(" ");
          }
          framesModel.addElement(s.substring(0, s.length() - 1));
        }
        this.listMotions.setModel(framesModel);
      } else {
        this.listMotions.setModel(new DefaultListModel<>());
      }
    }
  }

  @Override
  public void valueChanged(ListSelectionEvent e) {
    if (e.getSource() == this.listLayers) {
      if (this.listLayers.getSelectedIndex() != -1) {
        this.selectedLayer = this.listLayers.getSelectedIndex();
      }
    }
    if (e.getSource() == this.listShapes) {
      if (this.listShapes.getSelectedIndex() != -1) {
        this.selectedShape = this.listShapes.getSelectedIndex();
      }
    }
  }
}
