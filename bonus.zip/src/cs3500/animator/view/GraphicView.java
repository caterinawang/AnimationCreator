package cs3500.animator.view;

import java.awt.Dimension;
import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JScrollPane;

import cs3500.animator.controller.IController;
import cs3500.model.IReadOnlyModel;

/**
 * a class used to render Animations Visually.
 */
public class GraphicView extends JFrame implements IView {
  private DrawingPanel drawingPanel; // Must extend JPanel, so can not use interface

  /**
   * Constructs a graphic view of a specific animation.
   */
  GraphicView() {
    super();
    this.setTitle("Animation");
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.setSize(new Dimension(1100, 800));
    this.setLayout(new BorderLayout());
    this.setVisible(false);
  }

  @Override
  public void render(IReadOnlyModel model) {
    throw new UnsupportedOperationException("Can not render without a tick. Use renderVisual");
  }

  @Override
  public void renderVisual(IReadOnlyModel model, int tick) {
    if (model == null) {
      throw new IllegalArgumentException("Must supply a model.");
    }
    if (this.drawingPanel == null) {
      this.drawingPanel = new DrawingPanel();
      this.add(new JScrollPane(this.drawingPanel), BorderLayout.CENTER);
      this.setVisible(true);
    }
    this.drawingPanel.draw(model, tick);
  }

  @Override
  public void setListener(IController listener) {
    throw new UnsupportedOperationException("Listener can not be added to this view");
  }
}
