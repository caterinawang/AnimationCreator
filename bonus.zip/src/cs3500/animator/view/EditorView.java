package cs3500.animator.view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Map;

import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JMenuItem;
import javax.swing.JTextField;
import javax.swing.JTabbedPane;
import javax.swing.JPanel;
import javax.swing.ButtonGroup;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JLabel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import cs3500.animator.controller.IController;
import cs3500.model.Attribute;
import cs3500.model.IReadOnlyModel;

/**
 * Class to implement an editor view supporting playback controls and model mutation.
 */
public class EditorView extends GraphicView implements ActionListener,
        ChangeListener, IView {
  private IController listener;
  private ListPanel listPanel = new ListPanel(); // Extends JSplitPane, can not use interface
  // Playback GUI
  private final JMenuBar menuBar = new JMenuBar();
  private final JMenu playback = new JMenu("Playback");
  private final JCheckBoxMenuItem resume = new JCheckBoxMenuItem("Paused");
  private final JSlider scrubber = new JSlider(JSlider.HORIZONTAL);
  private final JMenuItem rewind = new JMenuItem("Rewind to Start");
  private final JCheckBoxMenuItem loop = new JCheckBoxMenuItem("Loop when Over");
  private final JMenuItem setSpeed = new JMenuItem("Set Speed (ms/tick) to: ");
  private final JTextField speed = new JTextField();
  // Modification GUI
  private final JTabbedPane modifierMenu = new JTabbedPane();
  // Add layer
  private final JPanel addLayerPanel = new JPanel();
  private final JTextField addLayerName = new JTextField(15);
  private final JButton addLayerButton = new JButton("Add Layer");
  // Remove layer
  private final JPanel removeLayerPanel = new JPanel();
  private final JTextField removeLayerName = new JTextField(15);
  private final JButton removeLayerButton = new JButton("Remove Layer");
  // Reorder layers
  private final JPanel reorderLayerPanel = new JPanel();
  private final JTextField reorderLayerName1 = new JTextField(15);
  private final JTextField reorderLayerName2 = new JTextField(15);
  private final JButton reorderLayerButton = new JButton("Reorder Layers");
  // Add Shape
  private final JPanel addShapePanel = new JPanel();
  private final JTextField addShapeLayer = new JTextField(15);
  private final JTextField addShapeName = new JTextField(15);
  private final ButtonGroup addShapeTypes = new ButtonGroup();
  private final JRadioButton addShapeRect = new JRadioButton("Rectangle");
  private final JRadioButton addShapeEllipse = new JRadioButton("Ellipse");
  private final JButton addShape = new JButton("Add Shape");
  // Remove Shape
  private final JPanel removeShapePanel = new JPanel();
  private final JTextField removeShapeName = new JTextField(15);
  private final JButton removeShape = new JButton("Remove Shape");
  // Move Shape
  private final JPanel moveShapePanel = new JPanel();
  private final JTextField moveShapeName = new JTextField(15);
  private final JTextField moveShapeLayer = new JTextField(15);
  private final JButton moveShapeButton = new JButton("Move Shape");
  // Add or Edit Keyframe
  private final JPanel addFramePanel = new JPanel();
  private final JTextField addFrameName = new JTextField(15);
  private final JTextField addFrameT = new JTextField(4);
  private final JTextField addFrameX = new JTextField(4);
  private final JTextField addFrameY = new JTextField(4);
  private final JTextField addFrameW = new JTextField(4);
  private final JTextField addFrameH = new JTextField(4);
  private final JTextField addFrameR = new JTextField(4);
  private final JTextField addFrameG = new JTextField(4);
  private final JTextField addFrameB = new JTextField(4);
  private final JTextField addFrameDeg = new JTextField(4);
  private final JButton addFrame = new JButton("Add or Edit Keyframe");
  // Remove Keyframe
  private final JPanel removeFramePanel = new JPanel();
  private final JTextField removeFrameName = new JTextField(15);
  private final JTextField removeFrameTick = new JTextField(4);
  private final JButton removeFrame = new JButton("Remove Keyframe");

  /**
   * Constructs a graphic view of a specific animation.
   */
  public EditorView() {
    super();
    this.modifierSetUp();
    this.playbackSetUp();
    this.add(listPanel, BorderLayout.EAST);
  }

  @Override
  public void renderVisual(IReadOnlyModel model, int tick) {
    super.renderVisual(model, tick);
    this.listPanel.draw(model, tick);
    Map<Attribute, Integer> attributes = model.getAttributes();
    this.scrubber.setMinimum(attributes.get(Attribute.start));
    this.scrubber.setMaximum(attributes.get(Attribute.end));
    this.scrubber.setValue(tick);
  }

  @Override
  public void setListener(IController listener) {
    if (listener == null) {
      throw new IllegalArgumentException("Can not set to null");
    }
    this.listener = listener;
  }

  @Override
  public void actionPerformed(ActionEvent e) {
    if (this.listener == null) {
      throw new UnsupportedOperationException("Listener not set");
    }
    try {
      switch (e.getActionCommand()) {
        case "Resume":
          this.listener.togglePause();
          break;
        case "Rewind":
          this.listener.rewind();
          break;
        case "Loop":
          this.listener.toggleLoop();
          break;
        case "Set Speed":
          this.listener.setTickRate(Integer.valueOf(this.speed.getText()));
          break;
        case "Add Layer":
          this.listener.addLayer(this.addLayerName.getText());
          break;
        case "Remove Layer":
          this.listener.removeLayer(this.removeLayerName.getText());
          break;
        case "Reorder Layers":
          this.listener.reorderLayer(this.reorderLayerName1.getText(),
                  this.reorderLayerName2.getText());
          break;
        case "Add Shape":
          if (this.addShapeEllipse.isSelected()) {
            this.listener.addShape(this.addShapeLayer.getText(),
                    this.addShapeName.getText(), "ellipse");
          }
          if (this.addShapeRect.isSelected()) {
            this.listener.addShape(this.addShapeLayer.getText(),
                    this.addShapeName.getText(), "rectangle");
          } else {
            throw new IllegalArgumentException("Must Select a shape type");
          }
          break;
        case "Remove Shape":
          this.listener.removeShape(this.removeShapeName.getText());
          break;
        case "Move Shape":
          this.listener.moveShape(this.moveShapeName.getText(), this.moveShapeLayer.getText());
          break;
        case "Add Keyframe":
          this.listener.addEditKeyframe(this.addFrameName.getText(),
                  Integer.valueOf(this.addFrameT.getText()),
                  Integer.valueOf(this.addFrameX.getText()),
                  Integer.valueOf(this.addFrameY.getText()),
                  Integer.valueOf(this.addFrameW.getText()),
                  Integer.valueOf(this.addFrameH.getText()),
                  Integer.valueOf(this.addFrameR.getText()),
                  Integer.valueOf(this.addFrameG.getText()),
                  Integer.valueOf(this.addFrameB.getText()),
                  Integer.valueOf(this.addFrameDeg.getText()));
          break;
        case "Remove Keyframe":
          this.listener.removeKeyframe(this.removeFrameName.getText(),
                  Integer.valueOf(this.removeFrameTick.getText()));
          break;
        default:
          throw new IllegalArgumentException("Unrecognized Command");
      }
    } catch (IllegalArgumentException error) {
      JFrame frame = new JFrame();
      JOptionPane.showMessageDialog(frame, error.getMessage(),
              "Error!", JOptionPane.ERROR_MESSAGE);
    }
  }

  /**
   * Sets up the menu required to modify models.
   */
  private void modifierSetUp() {
    this.modifierMenu.setPreferredSize(new Dimension(600, 90));
    // Add Layer Panel
    this.addLayerPanel.add(new JLabel("Name: "));
    this.addLayerPanel.add(this.addLayerName);
    this.addLayerPanel.add(this.addLayerButton);
    this.addLayerButton.addActionListener(this);
    this.addLayerButton.setActionCommand("Add Layer");
    this.modifierMenu.addTab("Add Layer", this.addLayerPanel);
    // Remove layer
    this.removeLayerPanel.add(new JLabel("Name: "));
    this.removeLayerPanel.add(this.removeLayerName);
    this.removeLayerPanel.add(this.removeLayerButton);
    this.removeLayerButton.addActionListener(this);
    this.removeLayerButton.setActionCommand("Remove Layer");
    this.modifierMenu.addTab("Remove Layer", this.removeLayerPanel);
    // Reorder layers
    this.reorderLayerPanel.add(new JLabel("Layer 1: "));
    this.reorderLayerPanel.add(this.reorderLayerName1);
    this.reorderLayerPanel.add(new JLabel("Layer 2: "));
    this.reorderLayerPanel.add(this.reorderLayerName2);
    this.reorderLayerPanel.add(this.reorderLayerButton);
    this.reorderLayerButton.addActionListener(this);
    this.reorderLayerButton.setActionCommand("Reorder Layers");
    this.modifierMenu.addTab("Reorder Layers", this.reorderLayerPanel);
    // Add Shape Panel
    this.addShapePanel.add(new JLabel("Type: "));
    this.addShapeTypes.add(this.addShapeRect);
    this.addShapeTypes.add(this.addShapeEllipse);
    this.addShapePanel.add(this.addShapeRect);
    this.addShapePanel.add(this.addShapeEllipse);
    this.addShapePanel.add(new JLabel("     Layer: "));
    this.addShapePanel.add(this.addShapeLayer);
    this.addShapePanel.add(new JLabel("Name: "));
    this.addShapePanel.add(this.addShapeName);
    this.addShape.setActionCommand("Add Shape");
    this.addShape.addActionListener(this);
    this.addShapePanel.add(this.addShape);
    this.modifierMenu.addTab("Add Shape", this.addShapePanel);
    // Remove Shape Panel
    this.removeShapePanel.add(new JLabel("Name: "));
    this.removeShapePanel.add(this.removeShapeName);
    this.removeShape.setActionCommand("Remove Shape");
    this.removeShape.addActionListener(this);
    this.removeShapePanel.add(this.removeShape);
    this.modifierMenu.addTab("Remove Shape", this.removeShapePanel);
    // Move Shape Panel
    this.moveShapePanel.add(new JLabel("Name: "));
    this.moveShapePanel.add(this.moveShapeName);
    this.moveShapePanel.add(new JLabel("Layer: "));
    this.moveShapePanel.add(this.moveShapeLayer);
    this.moveShapePanel.add(this.moveShapeButton);
    this.moveShapeButton.addActionListener(this);
    this.moveShapeButton.setActionCommand("Move Shape");
    this.modifierMenu.addTab("Move Shape", this.moveShapePanel);
    // Add or Edit Keyframe Panel
    this.addFramePanel.add(new JLabel("Name: "));
    this.addFramePanel.add(this.addFrameName);
    this.addFramePanel.add(new JLabel("Tick: "));
    this.addFramePanel.add(this.addFrameT);
    this.addFramePanel.add(new JLabel("X: "));
    this.addFramePanel.add(this.addFrameX);
    this.addFramePanel.add(new JLabel("Y: "));
    this.addFramePanel.add(this.addFrameY);
    this.addFramePanel.add(new JLabel("Width: "));
    this.addFramePanel.add(this.addFrameW);
    this.addFramePanel.add(new JLabel("Height: "));
    this.addFramePanel.add(this.addFrameH);
    this.addFramePanel.add(new JLabel("Red: "));
    this.addFramePanel.add(this.addFrameR);
    this.addFramePanel.add(new JLabel("Green: "));
    this.addFramePanel.add(this.addFrameG);
    this.addFramePanel.add(new JLabel("Blue: "));
    this.addFramePanel.add(this.addFrameB);
    this.addFramePanel.add(new JLabel("Rotation: "));
    this.addFramePanel.add(this.addFrameDeg);
    this.addFrame.setActionCommand("Add Keyframe");
    this.addFrame.addActionListener(this);
    this.addFramePanel.add(this.addFrame);
    this.modifierMenu.addTab("Add/Edit Keyframe", this.addFramePanel);
    // Remove Keyframe Panel
    this.removeFramePanel.add(new JLabel("Name: "));
    this.removeFramePanel.add(this.removeFrameName);
    this.removeFramePanel.add(new JLabel("Tick: "));
    this.removeFramePanel.add(this.removeFrameTick);
    this.removeFrame.setActionCommand("Remove Keyframe");
    this.removeFrame.addActionListener(this);
    this.removeFramePanel.add(this.removeFrame);
    this.modifierMenu.addTab("Remove Keyframe", this.removeFramePanel);
    // Add to frame
    this.add(this.modifierMenu, BorderLayout.SOUTH);
  }

  /**
   * Sets up the dropdown menu for playback controls.
   */
  private void playbackSetUp() {
    this.menuBar.add(this.playback);
    this.resume.setActionCommand("Resume");
    this.resume.addActionListener(this);
    this.playback.add(this.resume);
    this.playback.addSeparator();
    this.scrubber.addChangeListener(this);
    this.playback.add(scrubber);
    this.rewind.setActionCommand("Rewind");
    this.rewind.addActionListener(this);
    this.playback.add(this.rewind);
    this.loop.setActionCommand("Loop");
    this.loop.addActionListener(this);
    this.playback.add(this.loop);
    this.playback.addSeparator();
    this.setSpeed.setActionCommand("Set Speed");
    this.setSpeed.addActionListener(this);
    this.playback.add(this.setSpeed);
    this.playback.add(this.speed);
    this.add(this.menuBar, BorderLayout.NORTH);
  }

  @Override
  public void stateChanged(ChangeEvent e) {
    this.listener.setTick(this.scrubber.getValue());
  }
}
