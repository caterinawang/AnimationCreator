package cs3500.animator.view;

import java.io.IOException;
import java.util.Map;

import cs3500.animator.controller.IController;
import cs3500.model.Attribute;
import cs3500.model.IReadOnlyModel;
import cs3500.model.IReadOnlyShape;

/**
 * A class to represent a view as an SVG String.
 */
public class SVGView implements IView {
  private final Appendable out;
  private final int tickRate;

  SVGView(Appendable out, int tickRate) {
    this.out = out;
    this.tickRate = tickRate;
  }

  @Override
  public void render(IReadOnlyModel model) {
    if (model == null) {
      throw new IllegalArgumentException("Must supply a model.");
    }
    StringBuilder s = new StringBuilder();
    Map<Attribute, Integer> attributes = model.getAttributes();
    int width = attributes.get(Attribute.right);
    int height = attributes.get(Attribute.bottom);
    Map<String, IReadOnlyShape> shapes = model.getShapes();
    String header = "<svg width=\"" + width + "\" height=\"" + height + "\">\n";
    s.append(header);
    for (String name : shapes.keySet()) {
      String svgType;
      switch (shapes.get(name).type()) {
        case "rectangle":
          svgType = "rect";
          break;
        case "ellipse":
          svgType = "ellipse";
          break;
        default:
          svgType = "polygon";
      }
      String result = "<" + svgType + " id=\"" + name + "\" "
              + shapes.get(name).animateSVG(this.tickRate) + "</" + svgType + ">\n";
      s.append(result);
    }
    s.append("</svg>");
    try {
      this.out.append(s.toString());
    } catch (IOException e) {
      throw new IllegalStateException("Unable to append SVG");
    }
  }

  @Override
  public void renderVisual(IReadOnlyModel model, int tick) {
    throw new UnsupportedOperationException("Can not visually render models");
  }

  @Override
  public void setListener(IController listener) {
    throw new UnsupportedOperationException("Listener can not be added to this view");
  }
}
