package cs3500.animator.view;

/**
 * Interface representing methods used to create views dynamically.
 */
public interface IViewFactory {
  /**
   * Creates a view from the given string and additional parameters.
   *
   * @param type is the view type
   * @param out is the location to output text and SVG views
   * @param tickRate is the speed for SVG and visual views as ticks per second
   * @return an IView of the given type with given params
   */
  static IView createView(String type, Appendable out, double tickRate) {
    if (tickRate < 0) {
      throw new IllegalArgumentException("Speed can not be negative");
    }
    int msRate = (int) (1000 / tickRate); // conversion to milliseconds per tick
    switch (type) {
      case "text":
        return new TextualView(out);
      case "svg":
        return new SVGView(out, msRate);
      case "visual":
        return new GraphicView();
      case "edit":
        return new EditorView();
      default:
        throw new IllegalArgumentException("Unrecognized view type");
    }
  }
}
