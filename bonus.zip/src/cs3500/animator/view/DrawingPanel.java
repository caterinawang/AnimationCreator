package cs3500.animator.view;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Dimension;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.swing.JPanel;

import cs3500.model.Attribute;
import cs3500.model.IReadOnlyModel;
import cs3500.model.IReadOnlyShape;

/**
 * A class to create an animation panel.
 */
class DrawingPanel extends JPanel implements IDrawingPanel {
  private final List<IReadOnlyShape> shapes;
  private int currentTick;

  /**
   * Default constructor for drawing panels.
   */
  DrawingPanel() {
    super();
    this.shapes = new ArrayList<>();
  }

  @Override
  public void draw(IReadOnlyModel model, int tick) {
    Map<Attribute, Integer> attributes = model.getAttributes();
    int width = attributes.get(Attribute.right);
    int height = attributes.get(Attribute.bottom);
    this.setPreferredSize(new Dimension(width, height));

    Map<String, List<String>> layers = model.getLayers();
    Map<String, IReadOnlyShape> shapes = model.getShapes();
    this.shapes.clear();
    for (String layer : model.getLayerOrder()) {
      List<String> shapesToAdd = layers.get(layer);
      for (String shapeToAdd : shapesToAdd) {
        this.shapes.add(shapes.get(shapeToAdd));
      }
    }

    this.currentTick = tick;
    this.repaint();
  }

  @Override
  public void paintComponent(Graphics g) {
    super.paintComponent(g);
    for (IReadOnlyShape shape : this.shapes) {
      shape.animateGraphic((Graphics2D) g, this.currentTick);
    }
  }
}
