package cs3500.animator;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import cs3500.animator.controller.EditorController;
import cs3500.animator.controller.IController;
import cs3500.animator.util.AnimationReader;
import cs3500.animator.view.IView;
import cs3500.animator.view.IViewFactory;
import cs3500.model.AnimationModel;
import cs3500.model.IAnimationModel;

/**
 * Main class to run an animation.
 */
public class Excellence {
  /**
   * Main method to run an animation in a given view.
   *
   * @param args represents model and view params
   * @throws IllegalArgumentException if -speed is negative
   * @throws IllegalArgumentException if -out has IO errors
   * @throws IllegalArgumentException if -view or -in are not absent or invalid.
   */
  public static void main(String[] args) {
    try {
      IAnimationModel model = null;
      Appendable out = System.out;
      double tickRate = 1;
      String viewType = "";
      String outputLoc = null;

      for (int i = 0; i < args.length; i++) {
        String command = args[i];
        switch (command) {
          case "-speed":
            try {
              tickRate = Double.valueOf(args[i + 1]);
              i++;
              break;
            } catch (NumberFormatException e) {
              throw new IllegalArgumentException("Speed is not a valid value: " + args[i + 1]);
            }
          case "-view":
            viewType = args[i + 1];
            i++;
            break;
          case "-out":
            outputLoc = args[i + 1];
            out = new StringBuilder();
            i++;
            break;
          case "-in":
            try {
              Readable file = new FileReader(args[i + 1]);
              model = AnimationReader.parseFile(file, new AnimationModel.Builder());
              i++;
              break;
            } catch (FileNotFoundException e) {
              throw new IllegalArgumentException("Input file does not exist");
            }
          default:
            throw new IllegalArgumentException("Unrecognized command");
        }
      }
      IView view = IViewFactory.createView(viewType, out, tickRate);
      if (viewType.equals("visual") || viewType.equals("edit")) {
        IController controller = new EditorController(model, view, (int) (1000 / tickRate));
        if (viewType.equals("edit")) {
          view.setListener(controller);
        }
        controller.run();
      } else {
        view.render(model);
      }
      if (outputLoc != null && !viewType.equals("visual")) {
        try {
          FileWriter writer = new FileWriter(outputLoc);
          writer.write(out.toString());
          writer.close();
        } catch (IOException e) {
          throw new IllegalStateException("File could not be written");
        }
      }
    } catch (IllegalArgumentException | IllegalStateException e) {
      JFrame frame = new JFrame();
      JOptionPane.showMessageDialog(frame, e.getMessage(), "Error!", JOptionPane.ERROR_MESSAGE);
      System.exit(1);
    }
  }
}
