package cs3500.model;

import java.util.EnumMap;
import java.util.Map;

/**
 * A class to represent a motion between two keyframes.
 */
public class Motion implements IMotion {
  private final Map<Property, Integer> start;
  private final Map<Property, Integer> end;

  /**
   * Creates a motion spanning two keyframes.
   *
   * @param start first keyframe
   * @param end   second keyframe
   * @throws IllegalArgumentException if either keyframe is null
   * @throws IllegalArgumentException if second keyframe comes before first
   */
  public Motion(IKeyframe start, IKeyframe end) {
    if (start == null || end == null) {
      throw new IllegalArgumentException("Can not take in null keyframe");
    }
    if (end.getStart() < start.getStart()) {
      throw new IllegalArgumentException("Invalid order of keyframes");
    }
    this.start = start.getState();
    this.end = end.getState();
  }

  @Override
  public int getStart() {
    return this.start.get(Property.t);
  }

  @Override
  public Map<Property, Integer> getState(int tick) {
    int start = this.start.get(Property.t);
    int end = this.end.get(Property.t);

    if (tick > end || tick < start) {
      throw new IllegalArgumentException("Tick out of bounds");
    }
    if (tick == start) {
      return new EnumMap<>(this.start);
    }
    if (tick == end) {
      return new EnumMap<>(this.end);
    }
    EnumMap<Property, Integer> to_return = new EnumMap<>(Property.class);
    for (int i = 0; i < Property.list.length; i++) {
      Property p = Property.list[i];
      to_return.put(p, this.start.get(p) + ((this.end.get(p) - this.start.get(p))
              * (tick - start) / (end - start)));
    }
    return to_return;
  }

  @Override
  public String animateString() {
    StringBuilder s = new StringBuilder("motion");

    for (Integer val : this.start.values()) {
      s.append(" ");
      s.append(val);
    }
    for (Integer val : this.end.values()) {
      s.append(" ");
      s.append(val);
    }
    return s.toString();
  }

  /**
   * Returns an SVG string of a single property of this motion.
   *
   * @param p        is the property
   * @param attName  is the SVG name of the property
   * @param tickRate represents milliseconds per tick
   * @return property svg, if it changed
   */
  private String propertySVG(Property p, String attName, int tickRate) {
    int startTime = this.start.get(Property.t) * tickRate;
    int dur = this.end.get(Property.t) * tickRate - startTime;
    int from = this.start.get(p);
    int to = this.end.get(p);
    if (from != to) {
      return "  <animate attributeName=\"" + attName + "\" attributeType=\"XML\"\n "
              + "          begin=\"" + startTime + "ms\" dur=\"" + dur
              + "ms\" fill=\"freeze\" from=\"" + from + "\" to=\"" + to + "\" />\n";
    }
    return "";
  }

  @Override
  public String animateSVG(int tickRate) {
    StringBuilder s = new StringBuilder();
    s.append(this.propertySVG(Property.x, "x", tickRate));
    s.append(this.propertySVG(Property.y, "y", tickRate));
    s.append(this.propertySVG(Property.w, "width", tickRate));
    s.append(this.propertySVG(Property.h, "height", tickRate));
    int startTime = this.start.get(Property.t) * tickRate;
    int dur = this.end.get(Property.t) * tickRate - startTime;
    int r1 = this.start.get(Property.r);
    int g1 = this.start.get(Property.g);
    int b1 = this.start.get(Property.b);
    int r2 = this.end.get(Property.r);
    int g2 = this.end.get(Property.g);
    int b2 = this.end.get(Property.b);
    if (r1 != r2 || g1 != g2 || b1 != b2) {
      s.append("  <animate attributeName=\"fill\" attributeType=\"CSS\"\n"
              + "           begin=\"" + startTime + "ms\" dur=\"" + dur
              + "ms\" fill=\"freeze\" from=\"rgb(" + r1 + "," + g1 + "," + b1 + ")\" to=\"rgb("
              + r2 + "," + g2 + "," + b2 + ")\" />\n");
    }
    int deg1 = this.start.get(Property.deg);
    int deg2 = this.end.get(Property.deg);
    int centerX1 = this.start.get(Property.x) + this.start.get(Property.w) / 2;
    int centerY1 = this.start.get(Property.y) + this.start.get(Property.h) / 2;
    int centerX2 = this.end.get(Property.x) + this.end.get(Property.w) / 2;
    int centerY2 = this.end.get(Property.y) + this.end.get(Property.h) / 2;
    if (deg1 != deg2) {
      s.append("  <animateTransform attributeName=\"transform\" attributeType=\"XML\" type="
              + "\"rotate\" begin=\"" + startTime + "ms\""
              + "\n                    dur=\"" + dur + "ms\" from=\"" + deg1 + " " + centerX1
              + " " + centerY1 + "\" to=\"" + deg2 + " " + centerX2 + " " + centerY2 + "\"/>\n");
    }
    return s.toString();
  }
}
