package cs3500.model;

/**
 * An interface for methods on mutable animation models.
 */
public interface IAnimationModel extends IReadOnlyModel {
  /**
   * Adds the given keyframe, overriding present keyframe if at the same tick. Then sets model
   * bounds to accommodate new keyframe.
   *
   * @param name   shape to receive the keyframe
   * @param params the values for the keyframe to be added
   * @throws IllegalArgumentException if name is null
   * @throws IllegalArgumentException if params does not form valid keyframe
   */
  void addKeyframe(String name, int... params);

  /**
   * Removes the keyframe at the given tick from given shape, if it exists.
   *
   * @param name the name of the target shape
   * @param tick the time the keyframe occurs at
   * @throws IllegalArgumentException if shape name is not in model
   */
  void removeKeyframe(String name, int tick);

  /**
   * Adds a shape of the given name and type to the animation.
   *
   * @param layer the layer to add the shape to
   * @param name the name of shape to add
   * @param type the type of shape to add
   * @throws IllegalArgumentException if shape is present in model or type is undefined
   */
  void addShape(String layer, String name, String type);

  /**
   * Move the specified shape to specified layer.
   *
   * @param name shape to move
   * @param layer layer to move to
   * @throws IllegalArgumentException if name or layer are not in model
   */
  void moveShape(String name, String layer);

  /**
   * Removes the given shape from this animation, if it exists.
   *
   * @param name the name of the shape to remove
   */
  void removeShape(String name);

  /**
   * Add a layer with the given name to the end of the list of layers.
   *
   * @param name name of the layer
   * @throws IllegalArgumentException if name is null or already present
   */
  void addLayer(String name);

  /**
   * Removes the layer with the given name and all shapes in it, if it exists.
   *
   * @param name name of the layer
   */
  void removeLayer(String name);

  /**
   * Swaps the shapes within the two layers, effectively swapping their order.
   *
   * @param layer1 name of first layer
   * @param layer2 name of second layer
   */
  void reorderLayer(String layer1, String layer2);
}
