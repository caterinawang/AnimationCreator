package cs3500.model;

/**
 * An interface to represent methods on mutable shapes.
 */
public interface IAnimationShape extends IReadOnlyShape {
  /**
   * Adds the given keyframe at the given tick, overrides existing keyframe at same tick.

   * @param keyframe the motion to be added
   * @throws IllegalArgumentException if keyframe is null
   */
  void addKeyframe(IKeyframe keyframe);

  /**
   * Removes the keyframe at the given tick from this shape, if it exists.
   *
   * @param tick the time the keyframe occurs at
   */
  void removeKeyframe(int tick);
}
