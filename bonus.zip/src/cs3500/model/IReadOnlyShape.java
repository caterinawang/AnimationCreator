package cs3500.model;

import java.awt.Graphics2D;
import java.util.ArrayList;

/**
 * An interface to represent methods on immutable animation shapes.
 */
public interface IReadOnlyShape {
  /**
   * Creates a string representation of the animations on this shape.
   *
   * @return an animation in the form of a String
   */
  String animateString();

  /**
   * Updates a graphic to show one tick of this shape's animation. Graphic display depends on
   * specifications in controller/view.
   *
   * @param g    the graphic display
   * @param tick to represent the tick to display
   */
  void animateGraphic(Graphics2D g, int tick);

  /**
   * animates the shapes as SVG String.
   *
   * @param tickRate represents milliseconds per tick
   * @return the SVG representation of the shape.
   */
  String animateSVG(int tickRate);

  /**
   * Checks what type of shape this shape is.
   *
   * @return a string representing shape type
   */
  String type();

  /**
   * Gets a copy of all of the keyframes on this shape.
   *
   * @return a list of keyframes, sorted by tick
   */
  ArrayList<IKeyframe> getFrames();
}
