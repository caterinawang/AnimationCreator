package cs3500.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cs3500.animator.util.AnimationBuilder;

/**
 * A class to represent an animation model.
 */
public class AnimationModel implements IAnimationModel {
  private final List<String> layerOrder;
  private final Map<String, List<String>> layers;
  private final Map<String, IAnimationShape> shapes;
  private final Map<Attribute, Integer> attributes;

  /**
   * Private constructor to be used with builder.
   *
   * @param layers     the layers of shapes in this animation
   * @param shapes     is the shapes in the animation
   * @param attributes represents the four bounding canvas values
   */
  private AnimationModel(Map<String, List<String>> layers,
                         Map<String, IAnimationShape> shapes,
                         Map<Attribute, Integer> attributes) {
    if (shapes == null) {
      throw new IllegalArgumentException("Shapes can not be null");
    }
    this.layerOrder = new ArrayList<>(layers.keySet());
    this.layers = layers;
    this.shapes = shapes;
    this.attributes = attributes;
  }

  /**
   * Private constructor to be used with builder.
   */
  private AnimationModel() {
    this(new HashMap<>(), new HashMap<>(), new EnumMap<>(Attribute.class));
  }

  /**
   * Builder used to create an AnimationModel.
   */
  public static final class Builder implements AnimationBuilder<IAnimationModel> {
    private final AnimationModel model;

    /**
     * Builder constructor with default arguments.
     */
    public Builder() {
      this.model = new AnimationModel();
    }

    @Override
    public IAnimationModel build() {
      return this.model;
    }

    @Override
    public AnimationBuilder<IAnimationModel> setBounds(int x, int y, int width, int height) {
      this.model.setBounds(x, y, width, height);
      return this;
    }

    @Override
    public AnimationBuilder<IAnimationModel> declareShape(String layer, String name, String type) {
      if (!this.model.getLayerOrder().contains(layer)) {
        this.model.addLayer(layer);
      }
      this.model.addShape(layer, name, type);
      return this;
    }

    @Override
    public AnimationBuilder<IAnimationModel> addMotion(String name, int t1, int x1, int y1, int w1,
                                                       int h1, int r1, int g1, int b1, int deg1,
                                                       int t2, int x2, int y2, int w2, int h2,
                                                       int r2, int g2, int b2, int deg2) {
      this.model.addKeyframe(name, t1, x1, y1, w1, h1, r1, g1, b1, deg1);
      this.model.addKeyframe(name, t2, x2, y2, w2, h2, r2, g2, b2, deg2);
      return this;
    }

    @Override
    public AnimationBuilder<IAnimationModel> addKeyframe(String name, int t, int x, int y, int w,
                                                         int h, int r, int g, int b, int deg) {
      this.model.addKeyframe(name, t, x, y, w, h, r, g, b, deg);
      return this;
    }
  }

  /**
   * Specify the bounding box to be used for the animation. Boundaries can not be set lower than the
   * animation requires.
   *
   * @param x      The leftmost x value
   * @param y      The topmost y value
   * @param width  The width of the bounding box
   * @param height The height of the bounding box
   */
  private void setBounds(int x, int y, int width, int height) {
    this.attributes.put(Attribute.top,
            Math.min(this.attributes.getOrDefault(Attribute.top, Integer.MAX_VALUE), y));
    this.attributes.put(Attribute.bottom,
            Math.max(this.attributes.getOrDefault(Attribute.bottom, 0), height));
    this.attributes.put(Attribute.left,
            Math.min(this.attributes.getOrDefault(Attribute.left, Integer.MAX_VALUE), x));
    this.attributes.put(Attribute.right,
            Math.max(this.attributes.getOrDefault(Attribute.right, 0), width));
  }

  /**
   * Checks if the tick is before start or after end, then updates those values.
   *
   * @param tick is the newly added tick
   */
  private void setTimes(int tick) {
    this.attributes.put(Attribute.start,
            Math.min(this.attributes.getOrDefault(Attribute.start, Integer.MAX_VALUE), tick));
    this.attributes.put(Attribute.end,
            Math.max(this.attributes.getOrDefault(Attribute.end, 0), tick));
  }

  @Override
  public void addKeyframe(String name, int... params) {
    IAnimationShape target = this.shapes.get(name);
    if (target == null) {
      throw new IllegalArgumentException("Name not in model.");
    }
    target.addKeyframe(new Keyframe(params));
    this.setBounds(params[1], params[2], params[1] + params[3], params[2] + params[4]);
    this.setTimes(params[0]);
  }

  @Override
  public void removeKeyframe(String name, int tick) {
    IAnimationShape target = this.shapes.get(name);
    if (target == null) {
      throw new IllegalArgumentException("Name not in model.");
    }
    target.removeKeyframe(tick);
  }

  @Override
  public void addShape(String layer, String name, String type) {
    if (name == null || this.shapes.get(name) != null) {
      throw new IllegalArgumentException("Shape must have a unique name");
    }
    List<String> layerContents = this.layers.get(layer);
    if (layerContents == null) {
      throw new IllegalArgumentException("Layer is not in model");
    }
    layerContents.add(name);
    switch (type) {
      case "rectangle":
        shapes.put(name, new AnimatedRect());
        break;
      case "ellipse":
        shapes.put(name, new AnimatedEllipse());
        break;
      default:
        throw new IllegalArgumentException("Unrecognized shape type");
    }
  }

  @Override
  public void moveShape(String name, String layer) {
    if (this.shapes.get(name) == null || this.layers.get(layer) == null) {
      throw new IllegalArgumentException("Shape or layer not in model");
    }
    for (List<String> stored : this.layers.values()) {
      if (stored.contains(name)) {
        stored.remove(name);
        break;
      }
    }
    this.layers.get(layer).add(name);
  }

  @Override
  public void removeShape(String name) {
    if (this.shapes.get(name) != null) {
      for (List<String> layer : this.layers.values()) {
        if (layer.contains(name)) {
          layer.remove(name);
          break;
        }
      }
      this.shapes.remove(name);
    }
  }

  @Override
  public void addLayer(String name) {
    this.layerOrder.add(name);
    this.layers.put(name, new ArrayList<>());
  }

  @Override
  public void removeLayer(String name) {
    if (this.layerOrder.contains(name)) {
      for (String shapeName : this.layers.get(name)) {
        this.shapes.remove(shapeName);
      }
      this.layerOrder.remove(name);
      this.layers.remove(name);
    }
  }

  @Override
  public void reorderLayer(String layer1, String layer2) {
    if (!layerOrder.contains(layer1) || !layerOrder.contains(layer2)) {
      throw new IllegalArgumentException("Layers not in the model");
    }
    Collections.swap(this.layerOrder,
            this.layerOrder.indexOf(layer1), this.layerOrder.indexOf(layer2));
  }

  @Override
  public Map<String, IReadOnlyShape> getShapes() {
    return new HashMap<>(this.shapes);
  }

  @Override
  public List<String> getLayerOrder() {
    return new ArrayList<>(this.layerOrder);
  }

  @Override
  public Map<String, List<String>> getLayers() {
    return new HashMap<>(this.layers);
  }

  @Override
  public Map<Attribute, Integer> getAttributes() {
    if (this.attributes.isEmpty()) { // All values default to 0 if no keyframes were added
      EnumMap<Attribute, Integer> to_return = new EnumMap<>(Attribute.class);
      for (Attribute a : Attribute.list) {
        to_return.put(a, 0);
      }
      return to_return;
    }
    return new EnumMap<>(this.attributes);
  }
}
