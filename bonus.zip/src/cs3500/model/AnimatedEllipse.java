package cs3500.model;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;
import java.util.Map;

/**
 * A class to represent an animated oval or ellipse shape.
 */
public class AnimatedEllipse extends AnimationShape implements IAnimationShape {
  @Override
  public void animateGraphic(Graphics2D g, int tick) {
    Map<Property, Integer> state = this.getState(tick);
    if (state != null) {
      Color color = new Color(state.get(Property.r), state.get(Property.g), state.get(Property.b));
      g.setPaint(color);
      g.rotate(Math.toRadians(state.get(Property.deg)),
              state.get(Property.x) + state.get(Property.w) / 2,
              state.get(Property.y) + state.get(Property.h) / 2);
      g.fill(new Ellipse2D.Double(state.get(Property.x), state.get(Property.y),
              state.get(Property.w), state.get(Property.h)));
      g.rotate(Math.toRadians(-state.get(Property.deg)),
              state.get(Property.x) + state.get(Property.w) / 2,
              state.get(Property.y) + state.get(Property.h) / 2);
    }
  }

  @Override
  public String type() {
    return "ellipse";
  }
}
