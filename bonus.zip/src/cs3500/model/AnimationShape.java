package cs3500.model;

import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Abstract class to represent methods on animation shapes.
 */
public abstract class AnimationShape implements IAnimationShape {
  private final List<IKeyframe> frames;

  /**
   * Constructor to create an animation shape with no frames or motions.
   */
  AnimationShape() {
    this.frames = new ArrayList<>();
  }

  @Override
  public void addKeyframe(IKeyframe keyframe) {
    if (keyframe == null) {
      throw new IllegalArgumentException("Can not take null keyframe");
    }
    boolean added = false;
    for (int i = 0; i < this.frames.size(); i++) {
      IKeyframe stored = this.frames.get(i);
      if (stored.getStart() == keyframe.getStart()) { // Override
        this.frames.remove(i);
        this.frames.add(i, keyframe);
        added = true;
        break;
      }
      if (stored.getStart() > keyframe.getStart()) { // Add before next frame
        this.frames.add(i, keyframe);
        added = true;
        break;
      }
    }
    if (!added) { // Add at end
      this.frames.add(keyframe);
    }
  }

  @Override
  public void removeKeyframe(int tick) {
    for (int i = 0; i < this.frames.size(); i++) {
      IKeyframe stored = this.frames.get(i);
      if (stored.getStart() == tick) {
        this.frames.remove(stored);
        break;
      }
    }
  }

  /**
   * Creates the list of motions represented by this shape's keyframes.
   *
   * @return a list of motions on this shape.
   */
  private List<IMotion> makeMotions() {
    List<IMotion> motions = new ArrayList<>();
    for (int i = 0; i < this.frames.size() - 1; i++) {
      motions.add(new Motion(this.frames.get(i), this.frames.get(i + 1)));
    }
    return motions;
  }

  @Override
  public String animateString() {
    StringBuilder s = new StringBuilder();
    List<IMotion> motions = this.makeMotions();
    for (IMotion motion : motions) {
      s.append(motion.animateString());
      s.append("\n");
    }
    return s.toString();
  }

  /**
   * Private method to be called by subclasses in animateGraphic.
   *
   * @param tick of the current animation
   * @return the state of the shape at the given tick or null if shape is not shown
   */
  protected Map<Property, Integer> getState(int tick) {
    for (int i = 0; i < this.frames.size(); i++) {
      IKeyframe frame = this.frames.get(i);
      if (frame.getStart() > tick) {
        if (i == 0) {  // Tick before first appearance.
          return null;
        }
        IMotion motion = new Motion(this.frames.get(i - 1), frame);
        return motion.getState(tick);
      }
    }
    return null;
  }

  @Override
  public abstract void animateGraphic(Graphics2D g, int tick);

  @Override
  public String animateSVG(int tickRate) {
    StringBuilder s = new StringBuilder();
    List<IMotion> motions = this.makeMotions();
    if (!this.frames.isEmpty()) {
      IKeyframe first = this.frames.get(0);
      Map<Property, Integer> start = first.getState();
      s.append("x=\"" + start.get(Property.x) + "\" y=\"" + start.get(Property.y)
              + "\" width=\"" + start.get(Property.w) + "\" height=\"" + start.get(Property.h)
              + "\" fill=\"rgb(" + start.get(Property.r) + "," + start.get(Property.g) + ","
              + start.get(Property.b) + ")\"  >\n");
    }
    for (IMotion motion : motions) {
      s.append(motion.animateSVG(tickRate));
    }
    return s.toString();
  }

  @Override
  public abstract String type();

  @Override
  public ArrayList<IKeyframe> getFrames() {
    return new ArrayList<>(this.frames);
  }
}
