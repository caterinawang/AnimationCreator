package cs3500.model;

import java.util.Map;

/**
 * An interface to represent methods on keyframes of an animation.
 */
public interface IKeyframe {
  /**
   * Gets the start tick of this keyframe.
   *
   * @return the start tick
   */
  int getStart();

  /**
   * Copies the properties of this keyframe to avoid mutation.
   *
   * @return a map of state properties to values
   */
  Map<Property, Integer> getState();
}
