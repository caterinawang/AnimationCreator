package cs3500.model;

/**
 * An enum of the properties required to draw an animation shape.
 */
public enum Property {
  t, x, y, w, h, r, g, b, deg;

  public static Property[] list = Property.values();
}
