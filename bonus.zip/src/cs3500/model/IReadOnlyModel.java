package cs3500.model;

import java.util.List;
import java.util.Map;

/**
 * An interface to represent methods on immutable animation models.
 */
public interface IReadOnlyModel {
  /**
   * gets a list of all shapes in this model.
   * The shapes are immutable and already contain their motions.
   * @return a map of all shapes to their names.
   */
  Map<String, IReadOnlyShape> getShapes();

  /**
   * Gets the attributes of this model including the bounds, start, and end times.
   *
   * @return a map of the bound to its value.
   */
  Map<Attribute, Integer> getAttributes();

  /**
   * Gets the order of layers in this model.
   */
  List<String> getLayerOrder();

  /**
   * Gets the layers used in this model.
   */
  Map<String, List<String>> getLayers();
}
