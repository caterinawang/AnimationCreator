package cs3500.model;

import java.util.Map;

/**
 * An interface to represent methods on motions between two keyframes.
 */
public interface IMotion {
  /**
   * Gets the starting tick of this motion.
   *
   * @return start tick
   */
  int getStart();

  /**
   * Gets the state of a shape at a tick within this motion.
   *
   * @return a map of state properties to values
   */
  Map<Property, Integer> getState(int tick);

  /**
   * Creates a string representation of the animations on this Motion.
   *
   * @return an animation in the form of a String
   */
  String animateString();

  /**
   * Animates the motion as an SVG String.
   *
   * @param tickRate represents milliseconds per tick
   * @return the SVG representation of the motion.
   */
  String animateSVG(int tickRate);
}
