package cs3500.model;

import java.awt.Point;
import java.awt.Dimension;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.util.Map;

/**
 * A class to represent an animated rectangle shape.
 */
public class AnimatedRect extends AnimationShape implements IAnimationShape {
  @Override
  public void animateGraphic(Graphics2D g, int tick) {
    Map<Property, Integer> state = this.getState(tick);
    if (state != null) {
      Point pos = new Point(state.get(Property.x), state.get(Property.y));
      Dimension size = new Dimension(state.get(Property.w), state.get(Property.h));
      Color color = new Color(state.get(Property.r), state.get(Property.g), state.get(Property.b));
      g.setPaint(color);
      g.rotate(Math.toRadians(state.get(Property.deg)),
              pos.getX() + size.getWidth() / 2, pos.getY() + size.getHeight() / 2);
      g.fill(new Rectangle(pos, size));
      g.rotate(Math.toRadians(-state.get(Property.deg)),
              pos.getX() + size.getWidth() / 2, pos.getY() + size.getHeight() / 2);
    }
  }

  @Override
  public String type() {
    return "rectangle";
  }
}
