package cs3500.model;

import java.util.EnumMap;
import java.util.Map;

/**
 * A class to represent a single keyframe of a shape.
 */
public class Keyframe implements IKeyframe {
  private final Map<Property, Integer> properties;

  /**
   * Constructor that makes a keyframe from given parameters.
   *
   * @param params state of the keyframe.
   * @throws IllegalArgumentException if there are not 8 parameters
   * @throws IllegalArgumentException if any parameter is negative or colors are above 255
   */
  public Keyframe(int... params) {
    if (params.length != 9) {
      throw new IllegalArgumentException("Wrong number of parameters");
    }
    if (params[5] > 255 || params[6] > 255 || params[7] > 255) {
      throw new IllegalArgumentException("Color values can not exceed 255");
    }
    this.properties = new EnumMap<>(Property.class);
    for (int i = 0; i < params.length; i++) {
      properties.put(Property.list[i], params[i]);
    }
  }

  @Override
  public int getStart() {
    return this.properties.get(Property.t);
  }

  @Override
  public EnumMap<Property, Integer> getState() {
    return new EnumMap<>(this.properties);
  }
}
