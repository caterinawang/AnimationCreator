package cs3500.model;

/**
 * An enum to represent attributes of a model. These include the 4 bounds, start time, and end time.
 */
public enum Attribute {
  top, left, bottom, right, start, end;

  public static Attribute[] list = Attribute.values();
}
