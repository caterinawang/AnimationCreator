package cs3500.animator.controller;

import org.junit.Test;

import java.util.ArrayList;
import java.util.HashMap;

import cs3500.animator.view.EditorView;
import cs3500.animator.view.IView;
import cs3500.model.AnimationModel;
import cs3500.model.IAnimationModel;

import static org.junit.Assert.assertEquals;

/**
 * Class to test the methods on a controller that modify models. Other methods access private fields
 * and can only be tested at runtime.
 */
public class EditorControllerTest {
  private IView editor = new EditorView();
  private AnimationModel.Builder builder = new AnimationModel.Builder();
  private int[] frame1 = new int[]{0, 200, 200, 50, 100, 255, 0, 0};
  private int[] frame2 = new int[]{10, 200, 200, 50, 100, 255, 0, 0};
  private int[] frame3 = new int[]{50, 300, 100, 30, 150, 0, 255, 0};

  @Test(expected = IllegalArgumentException.class)
  public void testAddNullName() {
    IAnimationModel model = builder.build();
    IController controller = new EditorController(model, editor, 1000);
    controller.addShape("default",null, "Rectangle");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testAddInvalidType() {
    IAnimationModel model = builder.build();
    IController controller = new EditorController(model, editor, 1000);
    controller.addShape("default","A", "apple");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testAddExistingName() {
    IAnimationModel model = builder.build();
    IController controller = new EditorController(model, editor, 1000);
    controller.addShape("default","R", "rectangle");
    controller.addShape("default","R", "ellipse");
  }

  @Test // Tests addShape() and removeShape()
  public void changeShape() {
    IAnimationModel model = builder.build();
    IController controller = new EditorController(model, editor, 1000);
    assertEquals(model.getShapes(), new HashMap<>());
    controller.addShape("default","R", "rectangle");
    assertEquals(model.getShapes().get("R").type(), "rectangle");
    controller.addShape("default","E", "ellipse");
    assertEquals(model.getShapes().get("R").type(), "rectangle");
    assertEquals(model.getShapes().get("E").type(), "ellipse");
    controller.removeShape("O"); // nothing happens
    assertEquals(model.getShapes().get("R").type(), "rectangle");
    assertEquals(model.getShapes().get("E").type(), "ellipse");
    controller.removeShape("R");
    assertEquals(model.getShapes().get("R"), null);
    assertEquals(model.getShapes().get("E").type(), "ellipse");
    controller.removeShape("E");
    assertEquals(model.getShapes().get("R"), null);
    assertEquals(model.getShapes().get("E"), null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void addKeyframeNoShape1() {
    IAnimationModel model = builder.build();
    IController controller = new EditorController(model, editor, 1000);
    controller.addEditKeyframe(null, frame1);
  }

  @Test(expected = IllegalArgumentException.class)
  public void addKeyframeNoShape2() {
    IAnimationModel model = builder.build();
    IController controller = new EditorController(model, editor, 1000);
    controller.addEditKeyframe("", frame1);
  }

  @Test(expected = IllegalArgumentException.class)
  public void removeKeyframeNoShape1() {
    IAnimationModel model = builder.build();
    IController controller = new EditorController(model, editor, 1000);
    controller.removeKeyframe(null, 0);
  }

  @Test(expected = IllegalArgumentException.class)
  public void removeKeyframeNoShape2() {
    IAnimationModel model = builder.build();
    IController controller = new EditorController(model, editor, 1000);
    controller.removeKeyframe("", 0);
  }

  @Test(expected = IllegalArgumentException.class)
  public void removeKeyframeNoShape3() {
    IAnimationModel model = builder.build();
    IController controller = new EditorController(model, editor, 1000);
    model.addShape("default","R", "rectangle");
    controller.removeKeyframe("E", 0);
  }

  @Test // Tests addEditKeyframe and removeKeyframe
  public void changeKeyframe() {
    IAnimationModel model = builder.build();
    IController controller = new EditorController(model, editor, 1000);
    controller.addShape("default","R", "rectangle");
    controller.addShape("default","E", "ellipse");
    assertEquals(model.getShapes().get("R").getFrames(), new ArrayList<>());
    assertEquals(model.getShapes().get("E").getFrames(), new ArrayList<>());
    controller.addEditKeyframe("R", frame1);
    assertEquals(model.getShapes().get("R").getFrames().get(0).getStart(), 0);
    assertEquals(model.getShapes().get("E").getFrames(), new ArrayList<>());
    controller.addEditKeyframe("R", frame2);
    assertEquals(model.getShapes().get("R").getFrames().get(0).getStart(), 0);
    assertEquals(model.getShapes().get("R").getFrames().get(1).getStart(), 10);
    assertEquals(model.getShapes().get("E").getFrames(), new ArrayList<>());
    controller.addEditKeyframe("E", frame1);
    assertEquals(model.getShapes().get("R").getFrames().get(0).getStart(), 0);
    assertEquals(model.getShapes().get("R").getFrames().get(1).getStart(), 10);
    assertEquals(model.getShapes().get("E").getFrames().get(0).getStart(), 0);
    controller.removeKeyframe("R", 5); // nothing happens
    assertEquals(model.getShapes().get("R").getFrames().get(0).getStart(), 0);
    assertEquals(model.getShapes().get("R").getFrames().get(1).getStart(), 10);
    assertEquals(model.getShapes().get("E").getFrames().get(0).getStart(), 0);
    controller.removeKeyframe("R", 0);
    assertEquals(model.getShapes().get("R").getFrames().get(0).getStart(), 10);
    assertEquals(model.getShapes().get("E").getFrames().get(0).getStart(), 0);
    controller.removeKeyframe("E", 0);
    assertEquals(model.getShapes().get("R").getFrames().get(0).getStart(), 10);
    assertEquals(model.getShapes().get("E").getFrames(), new ArrayList<>());
  }
}