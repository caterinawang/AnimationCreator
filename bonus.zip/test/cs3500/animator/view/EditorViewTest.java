package cs3500.animator.view;

import org.junit.Test;

import java.awt.event.ActionEvent;

import cs3500.animator.controller.IController;
import cs3500.model.AnimationModel;
import cs3500.model.IAnimationModel;

import static org.junit.Assert.assertEquals;

/**
 * A class to test methods on an editor view. Some actions take private field inputs, and could only
 * be tested at runtime.
 */
public class EditorViewTest {
  private EditorView editorView = new EditorView(); // Uses class for ActionListener extension
  private IAnimationModel model = new AnimationModel.Builder().build();

  /**
   * Mock Controller to help view testing.
   */
  private class MockController implements IController {
    private final StringBuilder s; // Strictly StringBuilder to not test IOException

    private MockController(StringBuilder s) {
      this.s = s;
    }

    @Override
    public void run() {
      // Unnecessary field implementation
    }

    @Override
    public void togglePause() {
      s.setLength(0);
      s.append("Received Pause Command");
    }

    @Override
    public void rewind() {
      s.setLength(0);
      s.append("Received Rewind Command");
    }

    @Override
    public void setTick(int tick) {
      // Not tested due to field requirements.
    }

    @Override
    public void toggleLoop() {
      s.setLength(0);
      s.append("Received Loop Command");
    }

    @Override
    public void setTickRate(int tickRate) {
      // Not tested due to field requirements.
    }

    @Override
    public void addLayer(String name) {
      // Not tested due to field requirements.
    }

    @Override
    public void removeLayer(String name) {
      // Not tested due to field requirements.
    }

    @Override
    public void reorderLayer(String layer1, String layer2) {
      // Not tested due to field requirements.
    }

    @Override
    public void addShape(String layer, String name, String type) {
      // Not tested due to field requirements.
    }

    @Override
    public void removeShape(String name) {
      // Not tested due to field requirements.
    }

    @Override
    public void moveShape(String name, String layer) {
      // Not tested due to field requirements.
    }

    @Override
    public void addEditKeyframe(String name, int... params) {
      // Not tested due to field requirements.
    }

    @Override
    public void removeKeyframe(String name, int tick) {
      // Not tested due to field requirements.
    }
  }

  @Test(expected = UnsupportedOperationException.class)
  public void testRenderError() {
    this.editorView.render(model);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testRenderVisualNull() {
    this.editorView.renderVisual(null, 5);
  }

  @Test // Also tests setListener()
  public void actionPerformedNoParams() {
    StringBuilder s = new StringBuilder();
    this.editorView.setListener(new MockController(s));
    this.editorView.actionPerformed(new ActionEvent(this.editorView, 0, "Resume"));
    assertEquals(s.toString(), "Received Pause Command");
    this.editorView.actionPerformed(new ActionEvent(this.editorView, 0, "Rewind"));
    assertEquals(s.toString(), "Received Rewind Command");
    this.editorView.actionPerformed(new ActionEvent(this.editorView, 0, "Loop"));
    assertEquals(s.toString(), "Received Loop Command");
    // Other commands require input from fields and can not be tested here.
  }

  @Test(expected = IllegalArgumentException.class)
  public void setNullListener() {
    this.editorView.setListener(null);
  }

  @Test(expected = UnsupportedOperationException.class)
  public void testNoListener() {
    this.editorView.actionPerformed(new ActionEvent(this.editorView, 0, "Resume"));
  }
}