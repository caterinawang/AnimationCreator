package cs3500.animator.view;

import org.junit.Test;

import cs3500.animator.controller.EditorController;
import cs3500.model.AnimationModel;
import cs3500.model.IAnimationModel;

/**
 * Class to test errors on a graphic view.
 */
public class GraphicViewTest {
  private IView graphicView = new GraphicView();
  private IAnimationModel model = new AnimationModel.Builder().build();

  @Test (expected = UnsupportedOperationException.class)
  public void testRenderError() {
    this.graphicView.render(model);
  }

  @Test (expected = IllegalArgumentException.class)
  public void testRenderVisualNull() {
    this.graphicView.renderVisual(null, 5);
  }

  @Test (expected = UnsupportedOperationException.class)
  public void setListener() {
    this.graphicView.setListener(new EditorController(model, this.graphicView, 5));
  }
}