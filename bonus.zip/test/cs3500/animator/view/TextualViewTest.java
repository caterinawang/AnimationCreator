package cs3500.animator.view;

import org.junit.Test;

import cs3500.animator.controller.EditorController;
import cs3500.model.AnimationModel;
import cs3500.model.IAnimationModel;

import static org.junit.Assert.assertEquals;

/**
 * Class to test the methods on a textual view.
 */
public class TextualViewTest {
  private StringBuilder text = new StringBuilder();
  private IView view = IViewFactory.createView("text", text, 1);

  @Test(expected = IllegalArgumentException.class)
  public void renderNull() {
    view.render(null);
  }

  @Test
  public void render() {
    IAnimationModel model1 = new AnimationModel.Builder().build();
    view.render(model1);
    assertEquals(text.toString(), "canvas 0 0 0 0");
    text.setLength(0); // clear results
    AnimationModel.Builder builder = new AnimationModel.Builder();
    builder.declareShape("default","R", "rectangle");
    builder.declareShape("default","O", "ellipse");
    builder.addMotion("R", 0, 200, 200, 50, 100, 255, 0, 0, 0,
            10, 200, 200, 50, 100, 255, 0, 0, 0);
    builder.addMotion("R", 10, 200, 200, 50, 100, 255, 0, 0, 0,
            50, 300, 100, 50, 100, 255, 0, 0, 0);
    builder.addMotion("O", 70, 300, 300, 25, 150, 200, 100, 0, 0,
            100, 200, 200, 45, 100, 200, 0, 100, 0);
    IAnimationModel model2 = builder.build();
    view.render(model2);
    assertEquals(text.toString(), "canvas 200 100 350 450\n"
            + "shape R rectangle\n"
            + "motion 0 200 200 50 100 255 0 0 10 200 200 50 100 255 0 0\n"
            + "motion 10 200 200 50 100 255 0 0 50 300 100 50 100 255 0 0\n"
            + "\nshape O ellipse\n"
            + "motion 70 300 300 25 150 200 100 0 100 200 200 45 100 200 0 100\n");
  }

  @Test(expected = UnsupportedOperationException.class)
  public void renderVisual() {
    IAnimationModel model = new AnimationModel.Builder().build();
    view.renderVisual(model, 7);
  }

  @Test(expected = UnsupportedOperationException.class)
  public void setListener() {
    IAnimationModel model = new AnimationModel.Builder().build();
    view.setListener(new EditorController(model, view, 10));
  }
}