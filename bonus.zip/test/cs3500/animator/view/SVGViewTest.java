package cs3500.animator.view;

import org.junit.Test;

import cs3500.animator.controller.EditorController;
import cs3500.model.AnimationModel;
import cs3500.model.IAnimationModel;

import static org.junit.Assert.assertEquals;

/**
 * Class to test the methods on an SVG view.
 */
public class SVGViewTest {
  private StringBuilder svg = new StringBuilder();
  private IView view = IViewFactory.createView("svg", svg, 1);

  @Test(expected = IllegalArgumentException.class)
  public void renderNull() {
    view.render(null);
  }

  @Test
  public void render() {
    IAnimationModel model1 = new AnimationModel.Builder().build();
    view.render(model1);
    assertEquals(svg.toString(), "<svg width=\"0\" height=\"0\">\n</svg>");
    svg.setLength(0); // clear results
    AnimationModel.Builder builder = new AnimationModel.Builder();
    builder.declareShape("default", "R", "rectangle");
    builder.declareShape("default", "O", "ellipse");
    builder.addMotion("R", 0, 200, 200, 50, 100, 255, 0, 0, 0,
            10, 200, 200, 50, 100, 255, 0, 0, 0);
    builder.addMotion("R", 10, 200, 200, 50, 100, 255, 0, 0, 0,
            50, 300, 100, 50, 100, 255, 0, 0, 0);
    builder.addMotion("O", 70, 300, 300, 25, 150, 200, 100, 0, 0,
            100, 200, 200, 45, 100, 200, 0, 100, 0);
    IAnimationModel model2 = builder.build();
    view.render(model2);
    assertEquals(svg.toString(), "<svg width=\"350\" height=\"450\">\n"
            + "<rect id=\"R\" x=\"200\" y=\"200\" width=\"50\" height=\"100\""
            + " fill=\"rgb(255,0,0)\"  >\n  <animate attributeName=\"x\" attributeType=\"XML\""
            + "\n           begin=\"10000ms\" dur=\"40000ms\" fill=\"freeze\" from=\"200\" "
            + "to=\"300\" />\n  <animate attributeName=\"y\" attributeType=\"XML\""
            + "\n           begin=\"10000ms\" dur=\"40000ms\" fill=\"freeze\" from=\"200\" "
            + "to=\"100\" />\n</rect>\n<ellipse id=\"O\" x=\"300\" y=\"300\" width=\"25\" "
            + "height=\"150\" fill=\"rgb(200,100,0)\"  >\n"
            + "  <animate attributeName=\"x\" attributeType=\"XML\""
            + "\n           begin=\"70000ms\" dur=\"30000ms\" fill=\"freeze\" from=\"300\" "
            + "to=\"200\" />\n  <animate attributeName=\"y\" attributeType=\"XML\""
            + "\n           begin=\"70000ms\" dur=\"30000ms\" fill=\"freeze\" from=\"300\" "
            + "to=\"200\" />\n"
            + "  <animate attributeName=\"width\" attributeType=\"XML\""
            + "\n           begin=\"70000ms\" dur=\"30000ms\" fill=\"freeze\" from=\"25\" "
            + "to=\"45\" />\n  <animate attributeName=\"height\" attributeType=\"XML\""
            + "\n           begin=\"70000ms\" dur=\"30000ms\" fill=\"freeze\" from=\"150\" "
            + "to=\"100\" />\n"
            + "  <animate attributeName=\"fill\" attributeType=\"CSS\""
            + "\n           begin=\"70000ms\" dur=\"30000ms\" fill=\"freeze\" "
            + "from=\"rgb(200,100,0)\" to=\"rgb(200,0,100)\" />\n</ellipse>\n</svg>");
  }

  @Test(expected = UnsupportedOperationException.class)
  public void renderVisual() {
    IAnimationModel model = new AnimationModel.Builder().build();
    view.renderVisual(model, 7);
  }

  @Test(expected = UnsupportedOperationException.class)
  public void setListener() {
    IAnimationModel model = new AnimationModel.Builder().build();
    view.setListener(new EditorController(model, view, 10));
  }
}