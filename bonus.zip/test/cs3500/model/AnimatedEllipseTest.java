package cs3500.model;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;

/**
 * Class used to test methods on an Animated Oval.
 */
public class AnimatedEllipseTest {
  private IAnimationShape shape;
  private IKeyframe frame1 = new Keyframe(0, 200, 200, 50, 100, 255, 0, 0);
  private IKeyframe frame2 = new Keyframe(10, 200, 200, 50, 100, 255, 0, 0);
  private IKeyframe frame3 = new Keyframe(50, 300, 100, 30, 150, 0, 255, 0);
  private IKeyframe frame4 = new Keyframe(10, 0, 0, 0, 0, 0, 0, 0); // Override frame2

  /**
   * Initializes the shape to avoid mutation errors.
   */
  private void initData() {
    this.shape = new AnimatedEllipse();
  }

  @Test(expected = IllegalArgumentException.class)
  public void addNullKeyframe() {
    this.initData();
    this.shape.addKeyframe(null);
  }

  @Test // For addKeyframe, removeKeyframe, and getFrames
  public void changeKeyframe() {
    this.initData();
    List<IKeyframe> frames = new ArrayList<>();
    assertEquals(this.shape.getFrames(), frames);
    this.shape.addKeyframe(frame1);
    frames.add(frame1);
    assertEquals(this.shape.getFrames(), frames);
    this.shape.addKeyframe(frame2);
    frames.add(frame2);
    assertEquals(this.shape.getFrames(), frames);
    this.shape.addKeyframe(frame4);
    frames.add(frame4);
    frames.remove(frame2);
    assertEquals(this.shape.getFrames(), frames);
    this.shape.removeKeyframe(15); // nothing happens
    assertEquals(this.shape.getFrames(), frames);
    this.shape.removeKeyframe(0);
    frames.remove(frame1);
    assertEquals(this.shape.getFrames(), frames);
  }

  @Test
  public void animateString() {
    this.initData();
    assertEquals(shape.animateString(), "");
    this.shape.addKeyframe(frame1);
    assertEquals(shape.animateString(), "");
    this.shape.addKeyframe(frame2);
    assertEquals(shape.animateString(),
            "motion 0 200 200 50 100 255 0 0 10 200 200 50 100 255 0 0\n");
    this.shape.addKeyframe(frame3);
    assertEquals(shape.animateString(),
            "motion 0 200 200 50 100 255 0 0 10 200 200 50 100 255 0 0\n"
                    + "motion 10 200 200 50 100 255 0 0 50 300 100 30 150 0 255 0\n");
    this.shape.addKeyframe(frame4);
    assertEquals(shape.animateString(),
            "motion 0 200 200 50 100 255 0 0 10 0 0 0 0 0 0 0\n"
                    + "motion 10 0 0 0 0 0 0 0 50 300 100 30 150 0 255 0\n");
  }

  @Test
  public void animateSVG() {
    this.initData();
    assertEquals(this.shape.animateSVG(100), "");
    assertEquals(this.shape.animateSVG(1000), "");
    this.shape.addKeyframe(frame1);
    assertEquals(this.shape.animateSVG(100), "x=\"200\" y=\"200\" width=\"50\" height=\"100\""
            + " fill=\"rgb(255,0,0)\"  >\n");
    assertEquals(this.shape.animateSVG(1000), "x=\"200\" y=\"200\" width=\"50\" height=\"100\""
            + " fill=\"rgb(255,0,0)\"  >\n");
    this.shape.addKeyframe(frame2);
    this.shape.addKeyframe(frame3);
    assertEquals(this.shape.animateSVG(100), "x=\"200\" y=\"200\" width=\"50\" height=\"100\""
            + " fill=\"rgb(255,0,0)\"  >\n  <animate attributeName=\"x\" attributeType=\"XML\""
            + "\n           begin=\"1000ms\" dur=\"4000ms\" fill=\"freeze\" from=\"200\" "
            + "to=\"300\" />\n  <animate attributeName=\"y\" attributeType=\"XML\""
            + "\n           begin=\"1000ms\" dur=\"4000ms\" fill=\"freeze\" from=\"200\" "
            + "to=\"100\" />\n"
            + "  <animate attributeName=\"width\" attributeType=\"XML\""
            + "\n           begin=\"1000ms\" dur=\"4000ms\" fill=\"freeze\" from=\"50\" "
            + "to=\"30\" />\n  <animate attributeName=\"height\" attributeType=\"XML\""
            + "\n           begin=\"1000ms\" dur=\"4000ms\" fill=\"freeze\" from=\"100\" "
            + "to=\"150\" />\n"
            + "  <animate attributeName=\"fill\" attributeType=\"CSS\""
            + "\n           begin=\"1000ms\" dur=\"4000ms\" fill=\"freeze\" "
            + "from=\"rgb(255,0,0)\" to=\"rgb(0,255,0)\" />\n");
    this.shape.addKeyframe(new Keyframe(60, 400, 100, 50, 150, 0, 255, 0));
    assertEquals(this.shape.animateSVG(1000), "x=\"200\" y=\"200\" width=\"50\" height=\"100\""
            + " fill=\"rgb(255,0,0)\"  >\n  <animate attributeName=\"x\" attributeType=\"XML\""
            + "\n           begin=\"10000ms\" dur=\"40000ms\" fill=\"freeze\" from=\"200\" "
            + "to=\"300\" />\n  <animate attributeName=\"y\" attributeType=\"XML\""
            + "\n           begin=\"10000ms\" dur=\"40000ms\" fill=\"freeze\" from=\"200\" "
            + "to=\"100\" />\n"
            + "  <animate attributeName=\"width\" attributeType=\"XML\""
            + "\n           begin=\"10000ms\" dur=\"40000ms\" fill=\"freeze\" from=\"50\" "
            + "to=\"30\" />\n  <animate attributeName=\"height\" attributeType=\"XML\""
            + "\n           begin=\"10000ms\" dur=\"40000ms\" fill=\"freeze\" from=\"100\" "
            + "to=\"150\" />\n"
            + "  <animate attributeName=\"fill\" attributeType=\"CSS\""
            + "\n           begin=\"10000ms\" dur=\"40000ms\" fill=\"freeze\" "
            + "from=\"rgb(255,0,0)\" to=\"rgb(0,255,0)\" />\n"
            + "  <animate attributeName=\"x\" attributeType=\"XML\""
            + "\n           begin=\"50000ms\" dur=\"10000ms\" fill=\"freeze\" from=\"300\" "
            + "to=\"400\" />\n"
            + "  <animate attributeName=\"width\" attributeType=\"XML\""
            + "\n           begin=\"50000ms\" dur=\"10000ms\" fill=\"freeze\" from=\"30\" "
            + "to=\"50\" />\n");
  }

  @Test
  public void type() {
    this.initData();
    assertEquals(this.shape.type(), "ellipse");
  }
}