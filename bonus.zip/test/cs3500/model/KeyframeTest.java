package cs3500.model;

import org.junit.Test;

import java.util.EnumMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;

/**
 * Class to test the methods on a keyframe.
 */
public class KeyframeTest {
  private int[] values1 = new int[]{0, 100, 200, 50, 50, 255, 0, 0};
  private int[] values2 = new int[]{10, 200, 400, 20, 20, 100, 100, 100};
  private IKeyframe frame1 = new Keyframe(values1);
  private IKeyframe frame2 = new Keyframe(values2);

  @Test (expected = IllegalArgumentException.class)
  public void wrongParamCount1() {
    IKeyframe frame = new Keyframe(0);
  }

  @Test (expected = IllegalArgumentException.class)
  public void wrongParamCount2() {
    IKeyframe frame = new Keyframe(0, 100, 100);
  }

  @Test (expected = IllegalArgumentException.class)
  public void wrongParamCount3() {
    IKeyframe frame = new Keyframe(0, 100, 100, 50, 50, 255, 0, 0, 100);
  }

  @Test (expected = IllegalArgumentException.class)
  public void colorParamWrong1() {
    IKeyframe frame = new Keyframe(0, 100, 200, 50, 50, 256, 0, 0);
  }

  @Test (expected = IllegalArgumentException.class)
  public void colorParamWrong2() {
    IKeyframe frame = new Keyframe(0, 100, 200, 50, 50, 255, 300, 0);
  }

  @Test
  public void getStart() {
    assertEquals(frame1.getStart(), 0);
    assertEquals(frame2.getStart(), 10);
  }

  @Test
  public void getState() {
    Map<Property, Integer> states1 = new EnumMap<>(Property.class);
    Map<Property, Integer> states2 = new EnumMap<>(Property.class);
    for (int i = 0; i < 8; i++) {
      Property p = Property.list[i];
      states1.put(p, values1[i]);
      states2.put(p, values2[i]);
    }
    assertEquals(frame1.getState(), states1);
    assertEquals(frame2.getState(), states2);
  }
}