package cs3500.model;

import org.junit.Test;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;

/**
 * A class used to test methods in AnimationModel class.
 */
public class AnimationModelTest {
  private AnimationModel.Builder builder = new AnimationModel.Builder();
  private int[] frame1 = new int[]{0, 200, 200, 50, 100, 255, 0, 0};
  private int[] frame2 = new int[]{10, 200, 200, 50, 100, 255, 0, 0};
  private int[] frame3 = new int[]{50, 300, 100, 30, 150, 0, 255, 0};

  @Test (expected = IllegalArgumentException.class)
  public void testAddNullName() {
    IAnimationModel model = builder.build();
    model.addShape("default",null, "Rectangle");
  }

  @Test (expected = IllegalArgumentException.class)
  public void testAddInvalidType() {
    IAnimationModel model = builder.build();
    model.addShape("default","A", "apple");
  }

  @Test (expected = IllegalArgumentException.class)
  public void testAddExistingName() {
    IAnimationModel model = builder.build();
    model.addShape("default","R", "rectangle");
    model.addShape("default","R", "ellipse");
  }

  @Test // Tests addShape, removeShape, and getShapes
  public void changeShapes() {
    IAnimationModel model = builder.build();
    assertEquals(model.getShapes(), new HashMap<>());
    model.addShape("default","R", "rectangle");
    assertEquals(model.getShapes().get("R").type(), "rectangle");
    model.addShape("default","E", "ellipse");
    assertEquals(model.getShapes().get("R").type(), "rectangle");
    assertEquals(model.getShapes().get("E").type(), "ellipse");
    model.removeShape("O"); // nothing happens
    assertEquals(model.getShapes().get("R").type(), "rectangle");
    assertEquals(model.getShapes().get("E").type(), "ellipse");
    model.removeShape("R");
    assertEquals(model.getShapes().get("R"), null);
    assertEquals(model.getShapes().get("E").type(), "ellipse");
    model.removeShape("E");
    assertEquals(model.getShapes().get("R"), null);
    assertEquals(model.getShapes().get("E"), null);
  }

  @Test (expected = IllegalArgumentException.class)
  public void addKeyframeNoShape1() {
    IAnimationModel model = builder.build();
    model.addKeyframe(null, frame1);
  }

  @Test (expected = IllegalArgumentException.class)
  public void addKeyframeNoShape2() {
    IAnimationModel model = builder.build();
    model.addKeyframe("", frame1);
  }

  @Test (expected = IllegalArgumentException.class)
  public void removeKeyframeNoShape1() {
    IAnimationModel model = builder.build();
    model.removeKeyframe(null, 0);
  }

  @Test (expected = IllegalArgumentException.class)
  public void removeKeyframeNoShape2() {
    IAnimationModel model = builder.build();
    model.removeKeyframe("", 0);
  }

  @Test (expected = IllegalArgumentException.class)
  public void removeKeyframeNoShape3() {
    IAnimationModel model = builder.build();
    model.addShape("default","R", "rectangle");
    model.removeKeyframe("E", 0);
  }

  @Test // Tests addKeyframe and removeKeyframe
  public void changeKeyframe() {
    IAnimationModel model = builder.build();
    model.addShape("default","R", "rectangle");
    model.addShape("default","E", "ellipse");
    assertEquals(model.getShapes().get("R").getFrames(), new ArrayList<>());
    assertEquals(model.getShapes().get("E").getFrames(), new ArrayList<>());
    model.addKeyframe("R", frame1);
    assertEquals(model.getShapes().get("R").getFrames().get(0).getStart(), 0);
    assertEquals(model.getShapes().get("E").getFrames(), new ArrayList<>());
    model.addKeyframe("R", frame2);
    assertEquals(model.getShapes().get("R").getFrames().get(0).getStart(), 0);
    assertEquals(model.getShapes().get("R").getFrames().get(1).getStart(), 10);
    assertEquals(model.getShapes().get("E").getFrames(), new ArrayList<>());
    model.addKeyframe("E", frame1);
    assertEquals(model.getShapes().get("R").getFrames().get(0).getStart(), 0);
    assertEquals(model.getShapes().get("R").getFrames().get(1).getStart(), 10);
    assertEquals(model.getShapes().get("E").getFrames().get(0).getStart(), 0);
    model.removeKeyframe("R", 5); // nothing happens
    assertEquals(model.getShapes().get("R").getFrames().get(0).getStart(), 0);
    assertEquals(model.getShapes().get("R").getFrames().get(1).getStart(), 10);
    assertEquals(model.getShapes().get("E").getFrames().get(0).getStart(), 0);
    model.removeKeyframe("R", 0);
    assertEquals(model.getShapes().get("R").getFrames().get(0).getStart(), 10);
    assertEquals(model.getShapes().get("E").getFrames().get(0).getStart(), 0);
    model.removeKeyframe("E", 0);
    assertEquals(model.getShapes().get("R").getFrames().get(0).getStart(), 10);
    assertEquals(model.getShapes().get("E").getFrames(), new ArrayList<>());
  }

  @Test
  public void getAttributes() {
    IAnimationModel model = builder.build();
    model.addShape("default","R", "rectangle");
    model.addShape("default","E", "ellipse");
    Map<Attribute, Integer> attributes = new EnumMap<>(Attribute.class);
    for (Attribute a : Attribute.list) {
      attributes.put(a, 0);
    }
    assertEquals(model.getAttributes(), attributes);
    model.addKeyframe("R", frame1);
    attributes.put(Attribute.top, 200);
    attributes.put(Attribute.left, 200);
    attributes.put(Attribute.bottom, 300);
    attributes.put(Attribute.right, 250);
    assertEquals(model.getAttributes(), attributes);
    model.addKeyframe("E", frame1); // nothing changes
    assertEquals(model.getAttributes(), attributes);
    model.addKeyframe("E", frame2);
    attributes.put(Attribute.end, 10);
    assertEquals(model.getAttributes(), attributes);
    model.addKeyframe("E", frame3);
    attributes.put(Attribute.end, 50);
    attributes.put(Attribute.top, 100);
    attributes.put(Attribute.right, 330);
    assertEquals(model.getAttributes(), attributes);
  }
}
