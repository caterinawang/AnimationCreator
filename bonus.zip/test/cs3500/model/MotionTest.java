package cs3500.model;

import org.junit.Test;

import java.util.EnumMap;
import java.util.Map;

import static junit.framework.TestCase.assertEquals;

/**
 * a class used to test methods in the Motion class.
 */
public class MotionTest {
  private IMotion motion1 = new Motion(new Keyframe(0, 200, 200, 50, 100, 255, 0, 0),
          new Keyframe(10, 200, 200, 50, 100, 255, 0, 0));
  private IMotion motion2 = new Motion(new Keyframe(10, 200, 200, 50, 100, 255, 0, 0),
          new Keyframe(50, 300, 100, 50, 100, 255, 0, 0));
  private IMotion motion3 = new Motion(new Keyframe(70, 300, 300, 25, 150, 200, 100, 0),
          new Keyframe(100, 200, 200, 45, 100, 200, 0, 100));


  @Test(expected = IllegalArgumentException.class)
  public void testInvalidTickIntervalConstructor() {
    new Motion(new Keyframe(10, 200, 200, 50, 100, 255, 0, 0),
            new Keyframe(5, 200, 200, 50, 100, 255, 0, 0));
  }

  @Test(expected = IllegalArgumentException.class)
  public void nullKeyframe1() {
    new Motion(null, new Keyframe(10, 200, 200, 50, 100, 255, 0, 0));
  }

  @Test(expected = IllegalArgumentException.class)
  public void nullKeyframe2() {
    new Motion(new Keyframe(10, 200, 200, 50, 100, 255, 0, 0), null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void nullKeyframe3() {
    new Motion(null, null);
  }


  @Test
  public void testAnimateString1() {
    assertEquals(motion1.animateString(),
            "motion 0 200 200 50 100 255 0 0 10 200 200 50 100 255 0 0");
    assertEquals(motion2.animateString(),
            "motion 10 200 200 50 100 255 0 0 50 300 100 50 100 255 0 0");
  }

  @Test
  public void testAnimateSVG1() {
    assertEquals(motion1.animateSVG(0), "");
    assertEquals(motion1.animateSVG(1000), "");
    assertEquals(motion2.animateSVG(0), "  <animate attributeName=\"x\" attributeType=\"XML\""
            + "\n           begin=\"0ms\" dur=\"0ms\" fill=\"freeze\" from=\"200\" "
            + "to=\"300\" />\n  <animate attributeName=\"y\" attributeType=\"XML\""
            + "\n           begin=\"0ms\" dur=\"0ms\" fill=\"freeze\" from=\"200\" "
            + "to=\"100\" />\n");
    assertEquals(motion2.animateSVG(100), "  <animate attributeName=\"x\" attributeType=\"XML\""
            + "\n           begin=\"1000ms\" dur=\"4000ms\" fill=\"freeze\" from=\"200\" "
            + "to=\"300\" />\n  <animate attributeName=\"y\" attributeType=\"XML\""
            + "\n           begin=\"1000ms\" dur=\"4000ms\" fill=\"freeze\" from=\"200\" "
            + "to=\"100\" />\n");
    assertEquals(motion2.animateSVG(1000), "  <animate attributeName=\"x\" attributeType=\"XML\""
            + "\n           begin=\"10000ms\" dur=\"40000ms\" fill=\"freeze\" from=\"200\" "
            + "to=\"300\" />\n  <animate attributeName=\"y\" attributeType=\"XML\""
            + "\n           begin=\"10000ms\" dur=\"40000ms\" fill=\"freeze\" from=\"200\" "
            + "to=\"100\" />\n");
    assertEquals(motion3.animateSVG(1000), "  <animate attributeName=\"x\" attributeType=\"XML\""
            + "\n           begin=\"70000ms\" dur=\"30000ms\" fill=\"freeze\" from=\"300\" "
            + "to=\"200\" />\n  <animate attributeName=\"y\" attributeType=\"XML\""
            + "\n           begin=\"70000ms\" dur=\"30000ms\" fill=\"freeze\" from=\"300\" "
            + "to=\"200\" />\n"
            + "  <animate attributeName=\"width\" attributeType=\"XML\""
            + "\n           begin=\"70000ms\" dur=\"30000ms\" fill=\"freeze\" from=\"25\" "
            + "to=\"45\" />\n  <animate attributeName=\"height\" attributeType=\"XML\""
            + "\n           begin=\"70000ms\" dur=\"30000ms\" fill=\"freeze\" from=\"150\" "
            + "to=\"100\" />\n"
            + "  <animate attributeName=\"fill\" attributeType=\"CSS\""
            + "\n           begin=\"70000ms\" dur=\"30000ms\" fill=\"freeze\" "
            + "from=\"rgb(200,100,0)\" to=\"rgb(200,0,100)\" />\n");
  }

  @Test
  public void testGetStart() {
    assertEquals(motion1.getStart(), 0);
    assertEquals(motion2.getStart(), 10);
  }

  @Test
  public void testGetState() {
    Map<Property, Integer> m1state = new EnumMap<>(Property.class);
    Map<Property, Integer> m3state70 = new EnumMap<>(Property.class);
    Map<Property, Integer> m3state85 = new EnumMap<>(Property.class);
    Map<Property, Integer> m3state100 = new EnumMap<>(Property.class);
    int[] m1stateVal = new int[]{0, 200, 200, 50, 100, 255, 0, 0};
    int[] m3state70val = new int[]{70, 300, 300, 25, 150, 200, 100, 0};
    int[] m3state85val = new int[]{85, 250, 250, 35, 125, 200, 50, 50};
    int[] m3state100val = new int[]{100, 200, 200, 45, 100, 200, 0, 100};
    for (int i = 0; i < 8; i++) {
      Property p = Property.list[i];
      m1state.put(p, m1stateVal[i]);
      m3state70.put(p, m3state70val[i]);
      m3state85.put(p, m3state85val[i]);
      m3state100.put(p, m3state100val[i]);
    }

    assertEquals(motion1.getState(0), m1state);
    m1state.put(Property.t, 5);
    assertEquals(motion1.getState(5), m1state);
    m1state.put(Property.t, 10);
    assertEquals(motion1.getState(10), m1state);
    assertEquals(motion3.getState(70), m3state70);
    assertEquals(motion3.getState(85), m3state85);
    assertEquals(motion3.getState(100), m3state100);
  }


  @Test(expected = IllegalArgumentException.class)
  public void testGetInvalidTick1() {
    this.motion1.getState(11);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testGetInvalidTick2() {
    this.motion2.getState(9);
  }
}
